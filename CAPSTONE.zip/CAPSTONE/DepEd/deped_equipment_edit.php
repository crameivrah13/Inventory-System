<?php
	session_start();
	include_once('../connection/connection.php');

	if(isset($_POST['depedequipedit'])){
		$depedID = $_POST['depedID'];
		$quantity = $_POST['quantity'];
		$unit = $_POST['unit'];
		$category = $_POST['category'];
		$inventoryNo = $_POST['inventoryNo'];
		$dateAcquired = $_POST['dateAcquired'];
		$unitCost = $_POST['unitCost'];
		$sql = "UPDATE inventory SET quantity = '$quantity', unit = '$unit', category = '$category', inventoryNo = '$inventoryNo', dateAcquired = '$dateAcquired', unitCost = '$unitCost' WHERE depedID = '$depedID'";

		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'Item updated successfully';
		}
		
		else{
			$_SESSION['error'] = 'Something went wrong in updating item';
		}
	}
	else{
		$_SESSION['error'] = 'Select item to edit first';
	}

	header('location: deped_equipment_index.php');

?>