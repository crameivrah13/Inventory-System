<?php
	session_start();
	include_once('../connection/connection.php');

	if(isset($_POST['depededit'])){
		$depedID = $_POST['depedID'];
		$quantity = $_POST['quantity'];
		$unit = $_POST['unit'];
		$unitCost = $_POST['unitCost'];
		$totalCost = $_POST['totalCost'];
		$category = $_POST['category'];
		$inventoryNo = $_POST['inventoryNo'];
		$estimatedLife = $_POST['estimatedLife'];
		$sql = "UPDATE depedinventory SET quantity = '$quantity', unit = '$unit', unitCost = '$unitCost', totalCost = '$totalCost', category = '$category', inventoryNo = '$inventoryNo', estimatedLife = '$estimatedLife' WHERE depedID = '$depedID'";

		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'Item updated successfully';
		}
		
		else{
			$_SESSION['error'] = 'Something went wrong in updating item';
		}
	}
	else{
		$_SESSION['error'] = 'Select item to edit first';
	}

	header('location: deped_expendable_index.php');

?>