<?php
	session_start();
	include_once('../connection/connection.php');

	if(isset($_POST['depedequipadd'])){
		$quantity = $_POST['quantity'];
		$unit = $_POST['unit'];
		$category = $_POST['category'];
		$inventoryNo = $_POST['inventoryNo'];
		$dateAcquired = $_POST['dateAcquired'];
		$unitCost = $_POST['unitCost'];
		$sql = "INSERT INTO depedinventory (inventoryTypeID, inventorySubTypeID, quantity, unit, category, inventoryNo, dateAcquired, unitCost) VALUES (2, 3,'$quantity', '$unit', '$category', '$inventoryNo', '$dateAcquired', '$unitCost')";

		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'Item added successfully';
		}
		
		else{
			$_SESSION['error'] = 'Something went wrong while adding';
		}
	}
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}

	header('location: deped_equipment_index.php');
?>