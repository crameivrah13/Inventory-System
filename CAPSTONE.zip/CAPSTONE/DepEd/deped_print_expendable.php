<!DOCTYPE html>
<?php
    require '../connection/connection.php';
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Custodian Slip</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        h3 {
            text-align: center;
            color: black;
            margin-bottom: 20px;
        }

        .container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        .left-section {
            flex: 0 0 60%;
            margin-bottom: 0;
        }

        .right-section {
            flex: 0 0 35%;
            margin-top: 6%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ccc;
        }

        th {
            background-color: #007bff;
            color: #fff;
        }

        tbody tr:nth-child(odd) {
            background-color: #f9f9f9;
        }

        .footer {
            margin-top: 20px;
            text-align: left;
        }

        .footer-column {
            width: 50%;
            position: relative;
        }

        .signature-line {
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80%; /* Adjust this value as needed */
            border-bottom: 1px solid #333;
            padding-bottom: 5px; /* Optional: Add padding for spacing */
            margin-bottom: 10px; /* Optional: Add margin for spacing */
        }

        #PrintButton {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        #PrintButton:hover {
            background-color: #0056b3;
        }

        /* Header styles */
        .header {
            text-align: center;
            margin-bottom: 20px;
        }

        .logo {
            max-width: 70px; /* Adjust the size of the logo */
            margin-bottom: 5px;
        }
        .header > * {
            margin: 2px 0; /* Vertical margin for all header elements */
        }
        hr {
            border: 1px solid black;
        }
        .ph, .educ {
            font-family: 'Old English Text MT', fantasy; /* Specify Old English font */
            font-weight: bold; 
        }
        .region, .school, .si{
            font-family: 'Times New Roman', Times, serif; /* Specify Times New Roman font */
            font-weight: bold;
        }
        .float-end {
            text-align: right; /* Align text to the right */
            margin-bottom: 0; /* Remove bottom margin */
        }
    </style>
</head>
<body>
<div class="header">
    <img src="../images//depedlogo.png" alt="Logo" class="logo">
    <h4 class="ph">Republic of the Philippines</h4>
    <h3 class="educ">Department of Education</h3>
    <h5 class="region">Region III</h5>
    <h5 class="school">School Division of Bulacan</h5>
    <h5 class="si">San Ildefonso National High School</h5>
    <hr>
</div>
<div class="container-md">
    <div class="left-section">
        <h3>INVENTORY CUSTODIAN SLIP</h3>
        <!-- <p><b>Date Prepared:</b> <?php echo date("Y-m-d", strtotime("+6 HOURS")); ?></p> -->
        <p><b>Entity Name:</b> ____________________</p>
        <p><b>Fund Cluster:</b> ___________________</p>

    </div>
<div>
    <p style="text-align: right;"><b>ICS No:</b> ____________________</p>
</div>

<table>
    <thead>
        <tr>
            <th>Quantity</th>
            <th>Unit</th>
            <th>Unit Cost</th>
            <th>Total Cost</th>
            <th>Description</th>
            <th>Inventory Item No.</th>
            <th>Estimated Useful Life</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $query = $conn->query("SELECT * FROM depedinventory WHERE inventoryTypeID = 2 AND inventorySubTypeID = 2");
            while ($fetch = $query->fetch_array()) {
        ?>
        <tr>
            <td><?php echo $fetch['quantity']; ?></td>
            <td><?php echo $fetch['unit']; ?></td>
            <td><?php echo $fetch['unitCost']; ?></td>
            <td><?php echo $fetch['totalCost']; ?></td>
            <td><?php echo $fetch['category']; ?></td>
            <td><?php echo $fetch['inventoryNo']; ?></td>
            <td><?php echo $fetch['estimatedLife']; ?></td>
        </tr>
        <?php
            }
        ?>
    </tbody>
    <tfoot>
        <tr class="footer">
            <td colspan="4" class="footer-column">
                <p><b>Receiver from:</b></p>
                <p> __________________________</p>
                <p>Signature Over Printed Name</p>
                <p> __________________________</p>
                <p>Position/Office</p>
                <p> __________________________</p>
                <p>Date</p>
            </td>
            <td colspan="3" class="footer-column">
                <p><b>Receiver by:</b></p>
                <p> __________________________</p>
                <p>Signature Over Printed Name</p>
                <p> __________________________</p>
                <p>Position/Office</p>
                <p> __________________________</p>
                <p>Date</p>
            </td>
        </tr>
    </tfoot>
</table>
</div>

<!-- <button id="PrintButton" onclick="PrintPage()">Print</button> -->
<script>
    function PrintPage() {
        window.print();
    }
    window.addEventListener('DOMContentLoaded', (event) => {
   		PrintPage()
		setTimeout(function(){ window.close() },750)
	});
</script>

</body>
</html>
