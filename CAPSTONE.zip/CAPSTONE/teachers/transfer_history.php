<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transfer History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">


<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
    
<title>Transfer History</title>
<style>
    .container {
        max-width: 800px;
        margin: 0 auto;
        background-color: #fff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }
    h2 {
        color: #333;
        border-bottom: 2px solid #ccc;
        padding-bottom: 10px;
    }
    .transfer-box {
        border: 1px solid #ccc;
        padding: 10px;
        margin-bottom: 10px;
        border-radius: 5px;
        background-color: #f9f9f9;
        cursor: pointer;
    }
    .transfer-info {
        font-weight: bold;
    }
    /* Modal Styling */
    .modal-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        z-index: 999;
        justify-content: center;
        align-items: center;
    }
    .modal-content {
        background-color: #fff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
        max-width: 80%;
        text-align: left;
        position: relative; /* Added for positioning close button */
        width: 30%;
    }
    .close-modal {
        position: absolute;
        top: 10px;
        right: 10px;
        cursor: pointer;
    }
    .rounded-full {
  border-radius: 100%;
}

#wrapper {
  overflow-x: hidden;
}
#sidebar-wrapper {
  min-height: 100vh;
  margin-left: -15rem;
  -webkit-transition: margin 0.25s ease-out;
  -moz-transition: margin 0.25s ease-out;
  -o-transition: margin 0.25s ease-out;
  transition: margin 0.25s ease-out;
}

#sidebar-wrapper .sidebar-heading {
  padding: 0.875rem 1.25rem;
  font-size: 1.2rem;
}

#sidebar-wrapper .list-group {
  width: 15rem;
}

#page-content-wrapper {
  min-width: 100vw;
}

#wrapper.toggled #sidebar-wrapper {
  margin-left: 0;
}

#menu-toggle {
  cursor: pointer;
}

.list-group-item {
  border: none;
  padding: 20px 30px;
}

.list-group-item.active {
  background-color: transparent;
  color: var(--main-text-color);
  font-weight: bold;
  border: none;
}

@media (min-width: 768px) {
  #sidebar-wrapper {
    margin-left: 0;
  }

  #page-content-wrapper {
    min-width: 0;
    width: 100%;
  }

  #wrapper.toggled #sidebar-wrapper {
    margin-left: -15rem;
  }
}
</style>
</head>
<body>
<div class="d-flex" id="wrapper">
        <!-- Sidebar -->
        <div class="bg-secondary" id="sidebar-wrapper">
        <div class="sidebar-heading text-center primary-text fs-4 fw-bold text-uppercase border-bottom">
    <img src="../images/logo.png" alt="Logo" class="mb-3" style="width: 150px; height: auto; align-content:center;">
    <div style="font-family: sans-serif; color: #3f3a94; font-weight: bold; font-size: 2rem; text-align:center;">Inventory</div>
</div>
<div class="list-group list-group-flush my-3">
    <a href="../login/dashboard.php" class="list-group-item list-group-item-action bg-transparent second-text active">
        <i class="fas fa-chart-line me-2"></i>Dashboard
    </a>
    <div class="dropdown">
        <a class="list-group-item list-group-item-action bg-transparent second-text fw-bold dropdown-toggle" href="#" role="button" id="dropdownMOOE" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-money-bill-alt me-2"></i>MOOE
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownMOOE">
            <li><a class="dropdown-item" href="../mooe/mooe_supply_index.php"><i class="fas fa-shopping-cart me-2"></i>Supplies</a></li>
            <li><a class="dropdown-item" href="../mooe/mooe_expendable_index.php"><i class="fas fa-box-open me-2"></i>Semi-Expendable</a></li>
            <li><a class="dropdown-item" href="../mooe/mooe_equipment_index.php"><i class="fas fa-laptop me-2"></i>Property, Plant and Equipment</a></li>
        </ul>
    </div>
    <div class="dropdown">
        <a class="list-group-item list-group-item-action bg-transparent second-text fw-bold dropdown-toggle" href="#" role="button" id="dropdownDepEd" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-school me-2"></i>DepEd
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownDepEd">
            <li><a class="dropdown-item" href="#"><i class="fas fa-shopping-cart me-2"></i>Supplies</a></li>
            <li><a class="dropdown-item" href="../DepEd/deped_expendable_index.php"><i class="fas fa-box-open me-2"></i>Semi-Expendable</a></li>
            <li><a class="dropdown-item" href="../DepEd/deped_equipment_index.php"><i class="fas fa-laptop me-2"></i>Property, Plant and Equipment</a></li>
        </ul>
    </div>
    <div class="dropdown">
        <a class="list-group-item list-group-item-action bg-transparent second-text fw-bold dropdown-toggle" href="#" role="button" id="dropdownOthers" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-folder me-2"></i>Others
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownOthers">
            <li><a class="dropdown-item" href="#"><i class="fas fa-shopping-cart me-2"></i>Supplies</a></li>
            <li><a class="dropdown-item" href="../others/others_expendable_index.php"><i class="fas fa-box-open me-2"></i>Semi-Expendable</a></li>
            <li><a class="dropdown-item" href="../others/others_equipment_index.php"><i class="fas fa-laptop me-2"></i>Property, Plant and Equipment</a></li>
        </ul>
    </div>
    <a href="teachers_index.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
        <i class="fas fa-chalkboard-teacher me-2"></i>Teachers
    </a>
    <a href="accountability.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
    <i class="fas fa-users me-2"></i>Accountable List
</a>
    <a href="#" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
        <i class="fas fa-archive me-2"></i>Archived
    </a>
    <a href="../login/logout.php" class="list-group-item list-group-item-action bg-transparent text-danger fw-bold">
        <i class="fas fa-power-off me-2"></i>Logout
    </a>
</div>

</div>

        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <nav class="navbar navbar-expand-lg navbar-light bg-secondary py-4 px-4">
            <div class="d-flex align-items-center">
    <i class="fas fa-align-left primary-text fs-4 me-3" id="menu-toggle" style="z-index: 9999;"></i>
    <h2 class="fs-2 m-0"></h2>
</div>


            </nav>


<div class="container-fluid mt-4">
    <h2>Transfer History</h2>

    <!-- PHP logic embedded within HTML -->
    <?php
    // Include database connection and function to get teacher name
    require_once '../connection/connection.php';

    function getTeacherName($conn, $teachersID) {
        $sql = "SELECT CONCAT(fname, ' ', mname, ' ', lname) AS fullName FROM teacher WHERE teachersID = $teachersID";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            return $row["fullName"];
        } else {
            return "Unknown";
        }
    }

    // Query to retrieve transfer history
    $sql = "SELECT `transferFrom`, `transferTo`, category, quantity, transferDate FROM teachertransaction";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $fromId = $row["transferFrom"];
            $toId = $row["transferTo"];
            $category = $row["category"];
            $quantity = $row["quantity"];
            $date = date("n/j/y", strtotime($row["transferDate"])); // Format date as m/d/y

            // Get teacher names
            $from = getTeacherName($conn, $fromId);
            $to = getTeacherName($conn, $toId);

            // Display transfer information with names inside a styled box
            echo "<div class='transfer-box' onclick='showModal(\"$from\", \"$quantity\", \"$category\", \"$to\", \"$date\")'>";
            echo "<p><span class='transfer-info'>$from</span> transferred <span class='transfer-info'>$quantity</span> $category to <span class='transfer-info'>$to</span> on <span class='transfer-info'>$date</span>.</p>";
            echo "</div>";
        }
    } else {
        echo "<p>0 results</p>";
    }

    // Close database connection
    $conn->close();
    ?>

    <!-- Modal Overlay and Content -->
    <div class="modal-overlay" id="modalOverlay">
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal()">&times;</span>
            <h2>Transfer Details</h2>
            <p><strong>From:</strong> <span id="modalFrom"></span></p>
            <p><strong>Quantity:</strong> <span id="modalQuantity"></span></p>
            <p><strong>Category:</strong> <span id="modalCategory"></span></p>
            <p><strong>To:</strong> <span id="modalTo"></span></p>
            <p><strong>Date:</strong> <span id="modalDate"></span></p>
        </div>
    </div>
</div>
        </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function showModal(from, quantity, category, to, date) {
        document.getElementById('modalFrom').textContent = from;
        document.getElementById('modalQuantity').textContent = quantity;
        document.getElementById('modalCategory').textContent = category;
        document.getElementById('modalTo').textContent = to;
        document.getElementById('modalDate').textContent = date;
        document.getElementById('modalOverlay').style.display = 'flex';
    }

    function closeModal() {
        document.getElementById('modalOverlay').style.display = 'none';
    }
</script>
<script>
$(document).ready(function(){
       $("#menu-toggle").click(function(e) {
           e.preventDefault();
           $("#wrapper").toggleClass("toggled");
       });
   });
</script>

</body>
</html>
