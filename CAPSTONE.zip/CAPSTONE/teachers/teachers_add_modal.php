<!-- Add New -->
<div class="modal fade" id="teachersnewadd" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Add New</h4></center>
                
            </div>
            <div class="modal-body">
			<div class="container-fluid">
			<form method="POST" action="teachers_add.php">
				<div class="row form-group">
					<div class="col-sm-4">
						<label class="control-label modal-label">First Name:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="fname" required>
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Middle Name:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="mname" >
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Last Name:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="lname" required>
					</div>
				</div>
            </div> 
			</div>
            <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal" onclick="$('#teachersnewadd').modal('hide');">
      <span class="glyphicon glyphicon-remove"></span> Cancel
    <button type="submit" name="addteachers" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Save</button>
			</form>
            </div>

        </div>
    </div>
</div>
