<?php
include_once('../connection/connection.php');

if (isset($_POST['transferBtn'])) {
    $inventoryNo = mysqli_real_escape_string($conn, $_POST['inventoryNo']);
    $quantity = intval($_POST['quantity']);
    $newTeacherID = mysqli_real_escape_string($conn, $_POST['newTeacherID']);

    // Retrieve item details for the selected item
    $sql = "SELECT * FROM teacheraccountability WHERE inventoryNo = '$inventoryNo'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $currentTeacherID = $row['teachersID'];
        $currentQuantity = intval($row['quantity']); // Get current quantity from database

        // Validate if current quantity exists and is sufficient for transfer
        if ($currentQuantity > 0 && $currentQuantity >= $quantity) {
            // Calculate new quantity for the current teacher
            $newCurrentQuantity = $currentQuantity - $quantity;
            
            // Calculate new total cost for the current teacher
            $newCurrentTotalCost = $newCurrentQuantity * $row['unitCost']; 

            // Update current teacher's item quantity and total cost
            $updateCurrentTeacherItem = "UPDATE teacheraccountability 
                                         SET quantity = '$newCurrentQuantity', totalCost = '$newCurrentTotalCost' 
                                         WHERE accountabilityID = '{$row['accountabilityID']}'";

            if (!$conn->query($updateCurrentTeacherItem)) {
                die("Error updating current teacher's item: " . $conn->error);
            }

            // Check if new quantity is zero and delete the record
            if ($newCurrentQuantity <= 0) {
                $deleteItem = "DELETE FROM teacheraccountability 
                               WHERE accountabilityID = '{$row['accountabilityID']}'";

                if (!$conn->query($deleteItem)) {
                    // Rollback the update if deletion fails
                    $rollbackQuantity = intval($currentQuantity);
                    $rollbackTotalCost = $rollbackQuantity * floatval($row['unitCost']);

                    $updateRollbackItem = "UPDATE teacheraccountability 
                                           SET quantity = '$rollbackQuantity', totalCost = '$rollbackTotalCost' 
                                           WHERE accountabilityID = '{$row['accountabilityID']}'";

                    if (!$conn->query($updateRollbackItem)) {
                        die("Error rolling back update: " . $conn->error);
                    }

                    die("Error deleting item from current teacher: " . $conn->error);
                }
            }

            // Calculate total cost for the transferred quantity for the new teacher
            $newTotalCost = $quantity * $row['unitCost']; 

            // Insert new record for the new teacher with transferred item
            $insertNewTeacherItem = "INSERT INTO teacheraccountability 
                                     (inventoryNo, quantity, category, sourceOfFunding, unitCost, totalCost, dateOfIssue, remarks, teachersID) 
                                     VALUES ('$inventoryNo', '$quantity', '{$row['category']}', '{$row['sourceOfFunding']}', '{$row['unitCost']}', '$newTotalCost', '{$row['dateOfIssue']}', '{$row['remarks']}', '$newTeacherID')";

            if (!$conn->query($insertNewTeacherItem)) {
                // Rollback the update
                $rollbackQuantity = intval($currentQuantity);
                $rollbackTotalCost = $rollbackQuantity * floatval($row['unitCost']);

                $updateRollbackItem = "UPDATE teacheraccountability 
                                       SET quantity = '$rollbackQuantity', totalCost = '$rollbackTotalCost' 
                                       WHERE accountabilityID = '{$row['accountabilityID']}'";

                if (!$conn->query($updateRollbackItem)) {
                    die("Error rolling back update: " . $conn->error);
                }

                die("Error transferring item to new teacher: " . $conn->error);
            }

            // Transfer successful, record the transaction in item_transactions table
            $transferDate = date('Y-m-d H:i:s'); // Current date and time of transfer

            $transactionSql = "INSERT INTO teachertransaction (transferFrom, transferTo, category, inventoryNo, transferDate, quantity)
                               VALUES ('$currentTeacherID', '$newTeacherID', '{$row['category']}', '$inventoryNo', '$transferDate', '$quantity')";

            if ($conn->query($transactionSql) === TRUE) {
                echo "Item successfully transferred!";
            } else {
                die("Error recording transaction: " . $conn->error);
            }
        } else {
            echo "Insufficient quantity available for transfer.";
        }
    } else {
        echo "Item not found or query failed.";
    }
} else {
    echo "Transfer button not submitted.";
}

$conn->close();
?>
