<!-- Edit Modal -->
<div class="modal fade" id="editTeacherModal<?php echo $row['teachersID']; ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
			<button type="button" class="close" data-bs-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Edit Information</h4></center>
            </div>
            <div class="modal-body">
                <!-- Form to edit teacher's information -->
                <form method="POST" action="teachers_edit.php">
                    <input type="hidden" class="form-control" name="teachersID" value="<?php echo $row['teachersID']; ?>">
                    <div class="mb-3">
                        <label for="fname" class="form-label">First Name:</label>
                        <input type="text" class="form-control" id="fname" name="fname" value="<?php echo $row['fname']; ?>">
                    </div>
                    <div class="mb-3 mt-2">
                        <label for="mname" class="form-label">Middle Name:</label>
                        <input type="text" class="form-control" id="mname" name="mname" value="<?php echo $row['mname']; ?>">
                    </div>
                    <div class="mb-3 mt-2">
                        <label for="lname" class="form-label">Last Name:</label>
                        <input type="text" class="form-control" id="lname" name="lname" value="<?php echo $row['lname']; ?>">
                    </div>
                    <div class="mb-3 mt-2">
                        <label for="faculty" class="form-label">Faculty:</label>
                        <input type="text" class="form-control" id="faculty" name="faculty" value="<?php echo $row['faculty']; ?>">
                    </div>
                    
                    <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-bs-dismiss="modal">
                    <span class="glyphicon glyphicon-remove"></span> Cancel
                </button>
                <button type="submit" name="editteachers" class="btn btn-success">
                Update
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="view-modal<?php echo $row['accountID']; ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
			<button type="button" class="close" data-bs-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Accountability</h4></center>
            </div>
            <div class="modal-body">
                <!-- Form to edit teacher's information -->
                <form method="POST" action="">
                    <input type="hidden" class="form-control" name="accountID" value="<?php echo $row['accountID']; ?>">
                    <div class="mb-3">
                        <label for="fname" class="form-label">First Name:</label>
                        <input type="text" class="form-control" id="fname" name="fname" value="<?php echo $row['fname']; ?>">
                    </div>
                    <div class="mb-3 mt-2">
                        <label for="mname" class="form-label">Middle Name:</label>
                        <input type="text" class="form-control" id="mname" name="mname" value="<?php echo $row['mname']; ?>">
                    </div>
                    <div class="mb-3 mt-2">
                        <label for="lname" class="form-label">Last Name:</label>
                        <input type="text" class="form-control" id="lname" name="lname" value="<?php echo $row['lname']; ?>">
                    </div>
                    <div class="mb-3 mt-2">
                        <label for="faculty" class="form-label">Faculty:</label>
                        <input type="text" class="form-control" id="faculty" name="faculty" value="<?php echo $row['faculty']; ?>">
                    </div>
                    
                    <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-bs-dismiss="modal">
                    <span class="glyphicon glyphicon-remove"></span> Cancel
                </button>
                <button type="submit" name="editteachers" class="btn btn-success">
                Update
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
