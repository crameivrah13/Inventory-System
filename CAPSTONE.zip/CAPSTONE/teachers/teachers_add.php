<?php
	session_start();
	include_once('../connection/connection.php');

	if(isset($_POST['addteachers'])){
		$fname = $_POST['fname'];
		$mname = $_POST['mname'];
		$lname = $_POST['lname'];
		$sql = "INSERT INTO teacher (fname, mname, lname) VALUES ('$fname', '$mname', '$lname')";

		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'Teachers added successfully';
		}

		
		else{
			$_SESSION['error'] = 'Something went wrong while adding';
		}
	}
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}

	header('location: teachers_index.php');
?>