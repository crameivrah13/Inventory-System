<?php
	session_start();
	include_once('../connection/connection.php');

	if(isset($_POST['editteachers'])){
		$teachersID = $_POST['teachersID']; // Corrected the input name
		$fname = $_POST['fname'];
		$mname = $_POST['mname'];
		$lname = $_POST['lname'];
		$faculty = $_POST['faculty'];
		$sql = "UPDATE teachers SET fname = '$fname', mname = '$mname', lname = '$lname', faculty = '$faculty' WHERE teachersID = '$teachersID'"; // Corrected the variable name

		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'Teacher updated successfully';
		}
		else{
			$_SESSION['error'] = 'Something went wrong in updating teacher';
		}
	}
	else{
		$_SESSION['error'] = 'Select teacher to edit first';
	}

	header('location: teachers_index.php');

?>
