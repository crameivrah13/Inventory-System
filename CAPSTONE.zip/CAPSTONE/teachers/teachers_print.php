<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Teacher Accountability</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Custom styles for printing */
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            border: 1px solid #ddd;
            text-align: left;
        }
        h2 {
            color: #007bff;
        }
    </style>
</head>
<body>
    <?php
    // Include database connection
    include_once('../connection/connection.php');

    // Check if teachersID is provided in URL parameters
    if (isset($_GET['teachersID'])) {
        $selected_teacherID = $_GET['teachersID'];

        // Retrieve teacher's name based on teachersID
        $sql_teacher = "SELECT CONCAT(fname, ' ', mname, ' ', lname) AS full_name
                        FROM teacher
                        WHERE teachersID = $selected_teacherID";
        $result_teacher = $conn->query($sql_teacher);

        if ($result_teacher->num_rows > 0) {
            $teacher_row = $result_teacher->fetch_assoc();
            $teacher_name = $teacher_row['full_name'];

            echo "<h2>Accountability Items for: <mark>$teacher_name</mark></h2>";

            // Query accountability data for the selected teacher
            $sql = "SELECT quantity, category, inventoryNo, sourceOfFunding, unitCost, totalCost, dateOfIssue, remarks
                    FROM teacheraccountability
                    WHERE teachersID = $selected_teacherID";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<div class='table-responsive mt-4'>";
                echo "<table class='table table-bordered'>";
                echo "<thead>";
                echo "<tr>";
                echo "<th>Quantity</th>";
                echo "<th>Description</th>";
                echo "<th>Inventory No</th>";
                echo "<th>Source of Funding</th>";
                echo "<th>Unit Cost</th>";
                echo "<th>Total Cost</th>";
                echo "<th>Date of Issue</th>";
                echo "<th>Remarks</th>";
                echo "</tr>";
                echo "</thead>";
                echo "<tbody>";

                // Loop through the result set and populate the table rows
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>".$row['quantity']."</td>";
                    echo "<td>".$row['category']."</td>";
                    echo "<td>".$row['inventoryNo']."</td>";
                    echo "<td>".$row['sourceOfFunding']."</td>";
                    echo "<td>₱".$row['unitCost']."</td>"; // Assuming currency symbol for unit cost
                    echo "<td>₱".$row['totalCost']."</td>"; // Assuming currency symbol for total cost
                    echo "<td>".$row['dateOfIssue']."</td>";
                    echo "<td>".$row['remarks']."</td>";
                    echo "</tr>";
                }

                echo "</tbody>";
                echo "</table>";
                echo "</div>"; // Close table-responsive div

                // JavaScript for automatically triggering print dialog
                echo "<script>";
                echo "window.onload = function() {";
                echo "    window.print();"; // Trigger print dialog when page loads
                echo "}";
                echo "</script>";
            } else {
                echo "<p class='text-danger mt-4'>No accountability data available for selected teacher</p>";
            }
        } else {
            echo "<p class='text-danger mt-4'>Teacher not found</p>";
        }
    } else {
        echo "<p class='text-danger mt-4'>Invalid request: Teacher ID not provided</p>";
    }

    // Close database connection
    $conn->close();
    ?>
</body>
</html>
