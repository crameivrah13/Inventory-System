<?php
// Include database connection
include_once('../connection/connection.php');

// Check if teacherID is provided via POST
if (isset($_POST['teacherID'])) {
    // Get teacherID from POST data
    $teacherID = $_POST['teacherID'];

    // Prepare SQL statement to fetch items for the selected teacher
    $sql = "SELECT inventoryNo, category, quantity, unitCost FROM teacheraccountability WHERE teachersID = ?";
    
    // Use prepared statement to avoid SQL injection
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $teacherID); // 'i' for integer type (teacherID should be an integer)
    $stmt->execute();

    // Get result of the query
    $result = $stmt->get_result();

    // Check if there are rows returned
    if ($result->num_rows > 0) {
        // Loop through each row and output as radio buttons
        while ($row = $result->fetch_assoc()) {
            echo "<label>";
            echo "<input type='radio' name='selectedItem' value='" . $row['inventoryNo'] . "' data-description='" . $row['category'] . "' data-quantity='" . $row['quantity'] . "' data-unitprice='" . $row['unitCost'] . "' data-inventoryNo='" . $row['inventoryNo'] . "'>";
            echo $row['category'] . " - Inventory Number: " . $row['inventoryNo'] . " - Quantity: " . $row['quantity'] . " - Unit Price: $" . $row['unitCost'];
            echo "</label><br>";
        }
        
    } else {
        // If no items found for the teacher
        echo "No items found for this teacher.";
    }

    // Close prepared statement and database connection
    $stmt->close();
    $conn->close();
} else {
    // If teacherID is not provided
    echo "TeacherID is not provided.";
}
?>
