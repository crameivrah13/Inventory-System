<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accountability List</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        
        h2 {
            text-align: center;
            padding-bottom: 5px;
            padding-top: 10px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        th {
            background-color: #f2f2f2;
        }
        
        .viewBtn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
        }
        
        .viewBtn:hover {
            background-color: #45a049;
        }

        /* Style for the "Add New" button */
        .addNewBtn {
            margin-bottom: 2px;
            margin-right: 20px;
        }
    </style>
</head>
<body>
    <!-- Title -->
<div class="container-fluid">
    <?php include_once ('teachers_add_modal.php');?>
    <div class="card">
    <h2>Accountability List</h2>
    <!-- Add New button -->

    <div class="text-end addNewBtn">
        <a href="#teachersnewadd" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#teachersnewadd">
            <i class="fas fa-plus"></i> Add New
        </a>
    </div>
    <!-- Form -->
    <form action="view.php" method="post" id="viewForm">
        <input type="hidden" name="teacher_name" id="teacherName">
    </form>
    <!-- Table -->
    <div class="card-body">
    <table id="teacherTable">
        <thead>
            <tr>
                <th>Name</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <!-- Loop through teacher names and create rows with view button -->
            <?php
            // Include database connection
            include_once('../connection/connection.php');

            // Query to fetch names from teachers table

            $sql = "SELECT teachersID, CONCAT(fname, ' ', mname, ' ', lname) AS full_name FROM teachers";
            $result = $conn->query($sql);
            
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>".$row['full_name']."</td>";
                    echo "<td><button type='button' class='viewBtn' data-name='".$row['full_name']."'>View</button></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='2'>No available</td></tr>";
            }
            ?>
            
            
        </tbody>
    </table>
    </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#teacherTable').DataTable();
            
            $('.viewBtn').click(function() {
                var teacherName = $(this).data('name');
                $('#teacherName').val(teacherName);
                $('#viewForm').submit();
            });
        });
    </script>
</body>
</html>
