<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accountability Data</title>
   <!-- Bootstrap CSS -->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        h2 {
            color: #007bff;
        }
        .text-danger {
            color: red;
        }
        .rounded-full {
  border-radius: 100%;
}


#sidebar-wrapper {
  min-height: 100vh;
  margin-left: -15rem;
  -webkit-transition: margin 0.25s ease-out;
  -moz-transition: margin 0.25s ease-out;
  -o-transition: margin 0.25s ease-out;
  transition: margin 0.25s ease-out;
  
}

#sidebar-wrapper .sidebar-heading {
  padding: 0.875rem 1.25rem;
  font-size: 1.2rem;
}

#sidebar-wrapper .list-group {
  width: 15rem;
}

#page-content-wrapper {
  min-width: 100vw;
}

#wrapper.toggled #sidebar-wrapper {
  margin-left: 0;
}

#menu-toggle {
  cursor: pointer;
}

.list-group-item {
  border: none;
  padding: 20px 30px;
}

.list-group-item.active {
  background-color: transparent;
  color: var(--main-text-color);
  font-weight: bold;
  border: none;
}
#wrapper {
    display: flex;
}
nav {
    border-bottom: 1px solid #ddd; /* Idagdag ang horizontal line sa ilalim ng nav */
    margin-bottom: 20px; /* Magdagdag ng margin sa ibaba ng nav para magkaroon ng puwang */
}

#sidebar-wrapper {
    width: 250px; /* Ajustahin ang lapad ng sidebar base sa iyong design */
    height: 100vh; /* Itakda ang taas ng sidebar sa full height ng viewport */
    border-right: 1px solid #ddd; /* Idagdag ang vertical line */
}
@media (min-width: 768px) {
  #sidebar-wrapper {
    margin-left: 0;
  }

  #page-content-wrapper {
    min-width: 0;
    width: 100%;
  }

  #wrapper.toggled #sidebar-wrapper {
    margin-left: -15rem;
  }
}
        #accountabilityTable {
            width: 100%;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="d-flex" id="wrapper">
        <div class="bg-white" id="sidebar-wrapper">
        <div class="sidebar-heading text-center primary-text fs-4 fw-bold text-uppercase border-bottom">
    <img src="../images/logo.png" alt="Logo" class="mb-3" style="width: 150px; height: auto; align-content:center;">
    <div style="font-family: sans-serif; color: #3f3a94; font-weight: bold; font-size: 2rem; text-align:center;">Inventory</div>
</div>
           
<div class="list-group list-group-flush my-3">
    <a href="../login/dashboard.php" class="list-group-item list-group-item-action bg-transparent second-text active">
        <i class="fas fa-chart-line me-2"></i>Dashboard
    </a>
    <div class="dropdown">
        <a class="list-group-item list-group-item-action bg-transparent second-text fw-bold dropdown-toggle" href="#" role="button" id="dropdownMOOE" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-money-bill-alt me-2"></i>MOOE
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownMOOE">
            <li><a class="dropdown-item" href="#"><i class="fas fa-shopping-cart me-2"></i>Supplies</a></li>
            <li><a class="dropdown-item" href="mooe_expendable_index.php"><i class="fas fa-box-open me-2"></i>Semi-Expendable</a></li>
            <li><a class="dropdown-item" href="mooe_equipment_index.php"><i class="fas fa-laptop me-2"></i>Property, Plant and Equipment</a></li>
        </ul>
    </div>
    <div class="dropdown">
        <a class="list-group-item list-group-item-action bg-transparent second-text fw-bold dropdown-toggle" href="#" role="button" id="dropdownDepEd" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-school me-2"></i>DepEd
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownDepEd">
            <li><a class="dropdown-item" href="#"><i class="fas fa-shopping-cart me-2"></i>Supplies</a></li>
            <li><a class="dropdown-item" href="../DepEd/deped_expendable_index.php"><i class="fas fa-box-open me-2"></i>Semi-Expendable</a></li>
            <li><a class="dropdown-item" href="../DepEd/deped_equipment_index.php"><i class="fas fa-laptop me-2"></i>Property, Plant and Equipment</a></li>
        </ul>
    </div>
    <div class="dropdown">
        <a class="list-group-item list-group-item-action bg-transparent second-text fw-bold dropdown-toggle" href="#" role="button" id="dropdownOthers" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-folder me-2"></i>Others
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownOthers">
            <li><a class="dropdown-item" href="#"><i class="fas fa-shopping-cart me-2"></i>Supplies</a></li>
            <li><a class="dropdown-item" href="../others/others_expendable_index.php"><i class="fas fa-box-open me-2"></i>Semi-Expendable</a></li>
            <li><a class="dropdown-item" href="../others/others_equipment_index.php"><i class="fas fa-laptop me-2"></i>Property, Plant and Equipment</a></li>
        </ul>
    </div>
    <a href="../teachers_index.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
        <i class="fas fa-chalkboard-teacher me-2"></i>Teachers
    </a>
    <a href="accountability.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
    <i class="fas fa-users me-2"></i>Accountable List
</a>
    <a href="#" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
        <i class="fas fa-archive me-2"></i>Archived
    </a>
    <a href="../login/logout.php" class="list-group-item list-group-item-action bg-transparent text-danger fw-bold">
        <i class="fas fa-power-off me-2"></i>Logout
    </a>
</div>
        </div>

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-light bg-white py-4 px-4">
            <div class="d-flex align-items-center">
    <i class="fas fa-align-left primary-text fs-4 me-3" id="menu-toggle" style="z-index: 9999;"></i>
    <h2 class="fs-2 m-0"></h2>
</div>

            </nav>

            <!-- Main Content -->
            <div class="container-fluid">
                <div class="col-md-12">
                <div class="mt-4">
                    <?php
include_once('../connection/connection.php');

if (isset($_POST['teachersID'])) {
    $selected_teacherID = $_POST['teachersID'];

    
    // Retrieve teacher's name based on teachersID
    $sql_teacher = "SELECT CONCAT(fname, ' ', mname, ' ', lname) AS full_name
                    FROM teacher
                    WHERE teachersID = $selected_teacherID";
    $result_teacher = $conn->query($sql_teacher);

    if ($result_teacher->num_rows > 0) {
        $teacher_row = $result_teacher->fetch_assoc();
        $teacher_name = $teacher_row['full_name'];
    } else {
        $teacher_name = "Unknown"; // Default name if teacher not found
    }


    $sql = "SELECT quantity, category, inventoryNo, sourceOfFunding, unitCost, totalCost, dateOfIssue, remarks
            FROM teacheraccountability
            WHERE teachersID = $selected_teacherID";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<div class='table-responsive mt-4'>";
        echo "<h3>Accountability Item for: <mark>$teacher_name</mark></h3>";
        echo "<div class='d-flex justify-content-end mb-3'>";
        echo "<a href='teachers_print.php' onclick=\"printPage()\" class='btn btn-primary'><i class='fas fa-print'></i> Print</a>";
        echo "</div>";
        echo "<table id='accountabilityTable' class='table table-bordered table-striped'>";
        echo "<thead class='text-black'>";
        echo "<tr>";
        echo "<th>Quantity</th>";
        echo "<th>Description</th>";
        echo "<th>Inventory No</th>";
        echo "<th>Source of Funding</th>";
        echo "<th>Unit Cost</th>";
        echo "<th>Total Cost</th>";
        echo "<th>Date of Issue</th>";
        echo "<th>Remarks</th>";
        echo "<th>Action</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";


        // Loop through the result set and populate the table rows
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>".$row['quantity']."</td>";
            echo "<td>".$row['category']."</td>";
            echo "<td>".$row['inventoryNo']."</td>";
            echo "<td>".$row['sourceOfFunding']."</td>";
            echo "<td>₱".$row['unitCost']."</td>"; // Assuming currency symbol for unit cost
            echo "<td>₱".$row['totalCost']."</td>"; // Assuming currency symbol for total cost
            echo "<td>".$row['dateOfIssue']."</td>";
            echo "<td>".$row['remarks']."</td>";

            echo "<td>";
            echo "<a href='transfer_proccess.php?inventoryNo=".$row['inventoryNo']."' class='btn btn-info'>Transfer</a>";
            echo "</td>";
            echo "</tr>";
        }

        echo "</tbody>";
        echo "</table>";
        echo "</div>"; // Close table-responsive div
    } else {
        echo "<p class='text-danger mt-4'>No accountability data available for selected teacher</p>";
    }
}

$conn->close();
?>




                </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and jQuery (Required for DataTables) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    

    <script>
        // Initialize DataTables
        $(document).ready(function() {
            $('#accountabilityTable').DataTable();
        });
    </script>
        <script>
   $(document).ready(function(){
       $("#menu-toggle").click(function(e) {
           e.preventDefault();
           $("#wrapper").toggleClass("toggled");
       });
   });
</script>
<script>
// JavaScript to reset form on submit
    document.getElementById('teacherForm').addEventListener('submit', function() {
        console.log('Form submitted'); // Check if form submission is detected
        console.log('Selected index before reset:', document.getElementById('teacherID').selectedIndex); // Check current selected index
        document.getElementById('teacherID').selectedIndex = -1; // Clear selection of teacherID dropdown
        console.log('Selected index after reset:', document.getElementById('teacherID').selectedIndex); // Check selected index after reset
    });
    </script>
    <script>
    function printPage() {
        // Buksan ang print.php sa isang bagong window
        var printWindow = window.open('teachers_print.php', '_blank');

        // Focus sa bagong window at awtomatikong mag-print pagkatapos ng pag-load
        printWindow.onload = function() {
            printWindow.print();
        };
    }
</script>
</body>
</html>
