<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transfer Item</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        label {
            display: block;
            margin-bottom: 8px;
        }
        select,
        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        #teacherItems {
            margin-top: 20px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Transfer Item</h2>
    <form action="transfer_process.php" method="post" id="transferForm">
        <label for="teacherID">Select Current Teacher:</label>
        <select name="teacherID" id="teacherID" required>
            <!-- Loop through teachers data from database -->
            <?php
            include_once('../connection/connection.php');

            $sql = "SELECT teachersID, CONCAT(fname, ' ', lname) AS full_name FROM teacher";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['teachersID'] . "'>" . $row['full_name'] . "</option>";
                }
            }
            ?>
        </select>
        <button type="button" id="fetchItemsBtn">Fetch Teacher Items</button>

        <!-- Placeholder to display teacher's items -->
        <div id="teacherItems"></div>

        <!-- Hidden inputs for selected item details -->
        <input type="hidden" name="selectedItemID" id="selectedItemID">
        <label for="itemDescription">Item Description:</label>
        <input type="text" name="category" id="itemDescription" readonly>

        <label for="inventoryNo">Inventory Number:</label>
        <input type="number" name="inventoryNo" id="inventoryNo" readonly>

        <label for="quantity">Quantity:</label>
        <input type="number" name="quantity" id="quantity">

        <label for="unitPrice">Unit Price:</label>
        <input type="text" name="unitCost" id="unitPrice" readonly>

        <label for="totalPrice">Total Price:</label>
        <input type="text" name="totalCost" id="totalPrice" readonly>

        <!-- Select New Teacher -->
        <label for="newTeacherID">Select New Teacher:</label>
        <select name="newTeacherID" id="newTeacherID" required>
            <!-- Loop through teachers data from database -->
            <?php
            // Reset result set
            $result->data_seek(0);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['teachersID'] . "'>" . $row['full_name'] . "</option>";
                }
            }
            ?>
        </select>

        <button type="submit" name="transferBtn">Transfer Item</button>
    </form>
</div>

<script>
$(document).ready(function() {
    // AJAX request to fetch teacher's items when teacher is selected
    $('#fetchItemsBtn').click(function() {
        var teacherID = $('#teacherID').val(); // Get selected teacherID

        $.ajax({
            url: 'fetch_data.php',
            method: 'POST',
            data: { teacherID: teacherID }, // Pass teacherID as POST data
            success: function(response) {
                $('#teacherItems').html(response);
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    });

    // Handle item selection (populate item details)
    $(document).on('change', 'input[name="selectedItem"]', function() {
        var inventoryNo = $(this).val(); // Get inventory number from data attribute
        var category = $(this).data('description'); // Get category from data-description
        var quantity = $(this).data('quantity'); // Get quantity from data-quantity
        var unitPrice = $(this).data('unitprice'); // Get unit price from data-unitprice
        var totalPrice = quantity * unitPrice; // Calculate total price

        // Populate item details in the form fields
        $('#inventoryNo').val(inventoryNo);
        $('#itemDescription').val(category);
        $('#quantity').val(quantity);
        $('#unitPrice').val(unitPrice);
        $('#totalPrice').val(totalPrice);
    });
});


</script>

</body>
</html>