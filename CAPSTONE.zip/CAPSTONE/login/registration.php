<?php
session_start();
include '../connection/connection.php';

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT); // Hash the password

    $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$hashedPassword')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        ?>
            <script>
    alert("Registration Successful.");
    function navigateToPage() {
        window.location.href = 'index.php';
    }
    window.onload = function() {
        navigateToPage();
    }
</script>
        <?php 
    } else {
       echo "<script> alert('Registration Failed. Try Again');</script>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User Registration</title>
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        #container {
            border: 1px solid #3f3a94;
            width: 90%;
            max-width: 450px;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        form {
            margin-left: 10px;
        }

        input[type=text], input[type=password] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        label {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
            display: block;
        }

        a {
            text-decoration: none;
            font-weight: bold;
            font-size: 18px;
            color: blue;
            margin-left: 10px;
        }

        a:hover {
            color: purple;
        }

        input[type=submit] {
            width: 100%;
            background-color: #3f3a94;
            color: white;
            font-weight: bold;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type=submit]:hover {
            background-color: #3f3a94;
        ;
        }

        h1 {
            text-align: center;
            color: #3f3a94;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    
    <div id="container">
    <h1>REGISTER</h1>
        <form method="post" action="registration.php">
            <label for="username">Username:</label>
            <input type="text" name="username" placeholder="Enter Username" required>

            <label for="email">Email:</label>
            <input type="text" name="email" placeholder="Enter Your Email" required>

            <label for="password">Password:</label>
            <input type="password" name="password" placeholder="Enter Password" required>

            <input type="submit" name="register" value="Register">

            <label>Already have an account? <a href="index.php">Login</a></label>
        </form>
    </div>
</body>
</html>
