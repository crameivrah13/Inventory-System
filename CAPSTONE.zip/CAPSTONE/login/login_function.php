<?php
include '../connection.php';

// Login
if(isset($_POST['login'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $select = "SELECT * FROM acc WHERE email = '$email' AND password = '$password'";
    $result = mysqli_query($conn, $select);

    
    if(mysqli_num_rows($result) > 0){
        header('Location: ../others_expendable_index.php');
        exit;
    } else {
        echo "Incorrect email or password!";
    }
}
?>