<?php
session_start();
include '../connection/connection.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require './PHPMailer/src/Exception.php';
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $_SESSION['email']=$email;

    $sql = "SELECT * FROM users WHERE email='$email'";
    $query = mysqli_query($conn, $sql);
    $data = mysqli_fetch_array($query);

    if ($data && password_verify($password, $data['password'])) {
        $otp = rand(100000, 999999);
        $otp_expiry = date("Y-m-d H:i:s", strtotime("+3 minute"));
        $subject= "Your OTP for Login";
        $message="Your OTP is: $otp";

        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'sanildefonsonationalhighschool@gmail.com'; //host email 
        $mail->Password = 'fywijtdyypqhkgcs'; // app password of your host email
        $mail->Port = 465;
        $mail->SMTPSecure = 'ssl';
        $mail->isHTML(true);
        $mail->setFrom('sanildefonsonationalhighschool@gmail.com', 'San Ildefonso National High School Inventory System');//Sender's Email & Name
        $mail->addAddress($email,$name); //Receiver's Email and Name
        $mail->Subject = ("$subject");
        $mail->Body = $message;
        $mail->send();

        $sql1 = "UPDATE users SET otp='$otp', otp_expiry='$otp_expiry' WHERE id=".$data['id'];
        $query1 = mysqli_query($conn, $sql1);

        $_SESSION['temp_user'] = ['id' => $data['id'], 'otp' => $otp];
        header("Location: otp_verification.php");
        exit();
    } else {
        ?>
        <script>
           alert("Invalid Email or Password. Please try again.");
                function navigateToPage() {
                    window.location.href = 'index.php';
                }
                window.onload = function() {
                    navigateToPage();
                }
        </script>
        <?php 
    
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <title>Login Page</title>
    <style>
        html,
        body {
            height: 100%;
            width: 100%;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }

        main {
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .card {
            width: 320px;
            height: 450px;
            padding: 20px;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            position: relative;
            border: 1px solid #3f3a94;
        }

        .inventory-text,
        .sinhs,
        .welcome,
        .login {
            color: #3f3a94;
            text-align: left;
            margin-top: 10px;
        }

        .inventory-text {
            font-size: 40px;
            font-weight: bold;
        }

        .sinhs {
            font-size: 30px;
            position: absolute;
            top: 60px; /* Adjusted position */
            left: 19px; /* Adjusted position */
            color: grey;
        }

        .card-header {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .welcome {
            font-size: 24px;
            font-weight: bold;
            margin-top: 50px;
        }

        .login {
            font-size: 18px;
            color: grey;
            margin-bottom: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-control {
            width: 89%;
            height: 40px;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .btn-login {
            width: 101%;
            height: 40px;
            background-color: #3f3a94;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-login:hover {
            background-color: #2c275f;
        }

        .link-signup {
            text-align: center;
            margin-top: 10px;
        }

        .link-signup a {
            color: #3f3a94;
            text-decoration: none;
        }

        .link-signup a:hover {
            text-decoration: underline;
        }

        .additional-text {
            font-size: 14px;
            color: #888;
            text-align: center;
            margin-top: 10px;
        }
        .input-icon {
    position: relative;
}

.input-icon {
    position: relative;
}

.input-icon input {
    padding-left: 30px;
}

.input-icon i {
    position: absolute;
    left: 10px;
    top: 50%;
    transform: translateY(-50%);
    color: #aaa;
}
.logo-container {
    text-align: right; /* Center align the logo */
    ; /* Adjust margin as needed */
}

.logo {
    width: 150px; /* Adjust width as needed */
    height: auto; /* Maintain aspect ratio */
    position: absolute;
            top: 5%;
            right: -19px;
}

    </style>
</head>
<body>
    <main>
        <div class="card shadow">
        <div class="logo-container">
            <img src="../images/logo.png" alt="Logo" class="logo">
        </div>
            <div class="inventory-text">Inventory</div>
            <div class="sinhs">System</div>
            <div class="welcome">Welcome Back!</div>
            <div class="login">Please Log in to continue</div>
            <form method="post" action="index.php">
    <div class="form-group">
        <div class="input-icon">
            <i class="fas fa-envelope"></i>
            <input type="text" name="email" id="email" class="form-control" placeholder="Enter Your Email" required>
        </div>
    </div>
    <div class="form-group">
        <div class="input-icon">
            <i class="fas fa-lock"></i>
            <input type="password" name="password" id="password" class="form-control" placeholder="Enter Your Password" required>
        </div>
    </div>
    
    <div class="form-group">
        <input type="submit" name="login" value="Login" class="btn-login">
    </div>
</form>

            <div class="additional-text">
                Don't have an account? <a href="registration.php">Sign Up</a>
            </div>
            <div class="additional-text">
                Forgotten your password? <a href="forgotpassword.php">Reset Password</a>
            </div>
        </div>
    </main>
</body>
</html>
