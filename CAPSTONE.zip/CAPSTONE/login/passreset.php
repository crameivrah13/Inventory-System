<!DOCTYPE html>
<html>
<head>
    <title>Password Reset</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <style>
        .box {
            width: 40%;
            max-width: 600px;
            background-color: white;
            border: 1px solid #3f3a94;
            border-radius:5px;
            padding:16px;
            margin:0 auto;
            margin-top: 12%;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        .error {
            color: red;
            font-weight: 700;
        }

        input.parsley-success,
        select.parsley-success,
        textarea.parsley-success {
            color: #468847;
            background-color: #dff0d8;
            border: 1px solid #d6e9c6;
        }

        input.parsley-error,
        select.parsley-error,
        textarea.parsley-error {
            color: #b94a48;
            background-color: #f2dede;
            border: 1px solid #eed3d7;
        }

        .parsley-errors-list {
            margin: 2px 0 3px;
            padding: 0;
            list-style-type: none;
            font-size: 0.9em;
            line-height: 0.9em;
            opacity: 0;
            transition: all .3s ease-in;
            -o-transition: all .3s ease-in;
            -moz-transition: all .3s ease-in;
            -webkit-transition: all .3s ease-in;
        }

        .parsley-errors-list.filled {
            opacity: 1;
        }

        .parsley-type,
        .parsley-required,
        .parsley-equalto {
            color: #ff0000;
        }
        .btn {
    background-color: #3f3a94;
    color: white;
    width: 100%;
}
    </style>
</head>
<body>
<div class="container">
    <div class="table-responsive">
        <div class="box">
        <h1 style="text-align: center; color: #3f3a94;">Forgot Password</h1><br/>
    <hr>
            <?php
            include_once('../connection/connection.php');
            use PHPMailer\PHPMailer\PHPMailer;
            use PHPMailer\PHPMailer\Exception;
            require './PHPMailer/src/Exception.php';
            require './PHPMailer/src/PHPMailer.php';
            require './PHPMailer/src/SMTP.php';

            $msg = ''; // Initialize message variable

            if(isset($_POST['pwdrst'])) {
                $email = $_POST['email'];
                $password = $_POST['password'];
                $confirm_password = $_POST['cpwd'];

                if($password == $confirm_password) {
                    // Securely hash the password
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                    $reset_pwd = mysqli_query($conn, "UPDATE users SET password='$hashed_password' WHERE email='$email'");

                    if($reset_pwd) {
                      $msg = '<p style="color: green; font-weight: bold;">Your password has been updated successfully. <a href="index.php">Click here</a> to login.</p>';
                    } else {
                        $msg = "Error while updating password.";
                    }
                } else {
                    $msg = "Password and Confirm Password do not match";
                }
            }

            if(isset($_POST['forgot'])) {
                $email = $_POST['email'];
                $check_email = mysqli_query($conn,"select email from users where email='$email'");
                $res = mysqli_num_rows($check_email);
                if($res > 0) {
                    $message = '<div>
                                    <p><b>Hello!</b></p>
                                    <p>You are receiving this email because we received a password reset request for your account.</p>
                                    <br>
                                    <p><button class="btn btn-primary"><a href="http://localhost/SINHSCAPSTONE/login/passreset.php?email=' . urlencode($email) . '">Reset Password</a></button></p>
                                    <br>
                                    <p>If you did not request a password reset, no further action is required.</p>
                                </div>';

                    $mail = new PHPMailer;
                    $mail->IsSMTP();
                    $mail->SMTPAuth = true;
                    $mail->SMTPSecure = "tls";
                    $mail->Host = 'smtp.gmail.com';
                    $mail->Port = 587;
                    $mail->Username = "andiyue78@gmail.com";   //Enter your username/emailid
                    $mail->Password = "gpvhiadkefacvbjj";   //Enter your password
                    $mail->FromName = "SINHS";
                    $mail->AddAddress($email);
                    $mail->Subject = "Reset Password";
                    $mail->isHTML( TRUE );
                    $mail->Body =$message;
                    if($mail->send()) {
                        $msg = "We have e-mailed your password reset link!";
                    }
                } else {
                    $msg = "We can't find a user with that email address";
                }
            }
            ?>
            <form id="validate_form" method="post">
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="text" name="email" id="email" placeholder="Enter Email" required data-parsley-type="email" class="form-control"/>
                </div>
                <div class="form-group">
                    <label for="pwd">New Password</label>
                    <input type="password" name="password" id="pwd" placeholder="Enter Password" required class="form-control"/>
                </div>
                <div class="form-group">
                    <label for="cpwd">Confirm Password</label>
                    <input type="password" name="cpwd" id="cpwd" placeholder="Enter Confirm Password" required class="form-control"/>
                </div>
                <div class="form-group">
                    <input type="submit" id="login" name="pwdrst" value="Reset Password" class="btn" />
            
                </div>
                <p class="error"><?php echo $msg; ?></p>
            </form>
        </div>
    </div>
</div>
</body>
</html>
