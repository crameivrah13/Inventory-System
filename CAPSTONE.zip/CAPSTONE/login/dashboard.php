<?php session_start();

// Check if the user accessed this page from index.php
if (!isset($_SERVER['HTTP_REFERER']) || strpos($_SERVER['HTTP_REFERER'], 'index.php') === false) {
    // Redirect user back to index.php or display an error message
    header('Location: index.php');
    exit; // Stop further execution
}

// Start the session only if accessed from index.php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="styles.css" />
    <title></title>
</head>
<style>
.rounded-full {
  border-radius: 100%;
}

#wrapper {
  overflow-x: hidden;

}

#sidebar-wrapper {
  min-height: 100vh;
  margin-left: -15rem;
  -webkit-transition: margin 0.25s ease-out;
  -moz-transition: margin 0.25s ease-out;
  -o-transition: margin 0.25s ease-out;
  transition: margin 0.25s ease-out;
  
}

#sidebar-wrapper .sidebar-heading {
  padding: 0.875rem 1.25rem;
  font-size: 1.2rem;
}

#sidebar-wrapper .list-group {
  width: 15rem;
}

#page-content-wrapper {
  min-width: 100vw;
}

#wrapper.toggled #sidebar-wrapper {
  margin-left: 0;
}

#menu-toggle {
  cursor: pointer;
}

.list-group-item {
  border: none;
  padding: 20px 30px;
}

.list-group-item.active {
  background-color: transparent;
  color: var(--main-text-color);
  font-weight: bold;
  border: none;
}

@media (min-width: 768px) {
  #sidebar-wrapper {
    margin-left: 0;
  }

  #page-content-wrapper {
    min-width: 0;
    width: 100%;
  }

  #wrapper.toggled #sidebar-wrapper {
    margin-left: -15rem;
  }
}
</style>

<body>
<div class="d-flex" id="wrapper">
        <!-- Sidebar -->
        <div class="bg-light" id="sidebar-wrapper">
        <div class="sidebar-heading text-center primary-text fs-4 fw-bold text-uppercase border-bottom">
    <img src="../images/logo.png" alt="Logo" class="mb-3" style="width: 150px; height: auto;">
    <div style="font-family: 'Arial', sans-serif; color: #3f3a94; font-weight: bold; font-size: 2rem;">Inventory</div>
</div>

<div class="list-group list-group-flush my-3">
    <a href="dashboard.php" class="list-group-item list-group-item-action bg-transparent second-text active">
        <i class="fas fa-chart-line me-2"></i>Dashboard
    </a>
    <div class="dropdown">
        <a class="list-group-item list-group-item-action bg-transparent second-text fw-bold dropdown-toggle" href="#" role="button" id="dropdownMOOE" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-money-bill-alt me-2"></i>MOOE
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownMOOE">
            <li><a class="dropdown-item" href="#"><i class="fas fa-shopping-cart me-2"></i>Supplies</a></li>
            <li><a class="dropdown-item" href="../mooe/mooe_expendable_index.php"><i class="fas fa-box-open me-2"></i>Semi-Expendable</a></li>
            <li><a class="dropdown-item" href="../mooe/mooe_equipment_index.php"><i class="fas fa-laptop me-2"></i>Property, Plant and Equipment</a></li>
        </ul>
    </div>
    <div class="dropdown">
        <a class="list-group-item list-group-item-action bg-transparent second-text fw-bold dropdown-toggle" href="#" role="button" id="dropdownDepEd" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-school me-2"></i>DepEd
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownDepEd">
            <li><a class="dropdown-item" href="#"><i class="fas fa-shopping-cart me-2"></i>Supplies</a></li>
            <li><a class="dropdown-item" href="../DepEd/deped_expendable_index.php"><i class="fas fa-box-open me-2"></i>Semi-Expendable</a></li>
            <li><a class="dropdown-item" href="../DepEd/deped_equipment_index.php"><i class="fas fa-laptop me-2"></i>Property, Plant and Equipment</a></li>
        </ul>
    </div>
    <div class="dropdown">
        <a class="list-group-item list-group-item-action bg-transparent second-text fw-bold dropdown-toggle" href="#" role="button" id="dropdownOthers" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-folder me-2"></i>Others
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownOthers">
            <li><a class="dropdown-item" href="#"><i class="fas fa-shopping-cart me-2"></i>Supplies</a></li>
            <li><a class="dropdown-item" href="../others/others_expendable_index.php"><i class="fas fa-box-open me-2"></i>Semi-Expendable</a></li>
            <li><a class="dropdown-item" href="../others/others_equipment_index.php"><i class="fas fa-laptop me-2"></i>Property, Plant and Equipment</a></li>
        </ul>
    </div>
    <a href="../teachers/teachers_index.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
        <i class="fas fa-chalkboard-teacher me-2"></i>Teachers
    </a>
    <a href="#" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
        <i class="fas fa-archive me-2"></i>Archived
    </a>
    <a href="logout.php" class="list-group-item list-group-item-action bg-transparent text-danger fw-bold">
        <i class="fas fa-power-off me-2"></i>Logout
    </a>
</div>

</div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <nav class="navbar navbar-expand-lg navbar-light bg-light py-4 px-4">
                <div class="d-flex align-items-center">
                    <i class="fas fa-align-left primary-text fs-4 me-3" id="menu-toggle"></i>
                    <h2 class="fs-2 m-0">Dashboard</h2>
                </div>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle second-text fw-bold" href="#" id="navbarDropdown"
                                role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user me-2"></i>Dave Kylle
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="#">Profile</a></li>
                                <li><a class="dropdown-item" href="#">Settings</a></li>
                                <li><a class="dropdown-item" href="#">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>

            <?php


include '../connection/connection.php'; // Include your database connection file

// Assuming the user is already logged in and you have their user_id stored in $_SESSION['user_id']
if(isset($_SESSION['user_id'])) {
    // Fetch the user details from the database
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT username FROM users WHERE id = $user_id"; // Adjust this query according to your database schema
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) > 0) {
        // If user exists, fetch their username and store it in the session
        $row = mysqli_fetch_assoc($result);
        $_SESSION['username'] = $row['username'];
    } else {
        // Handle the case where the user does not exist
        // You can redirect the user to a login page or display an error message
    }
}
?>

<body> 
    <main>
<div class="container-fluid py-3" id="page-container">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="card shadow rounded-0">
                    <div class="card-body py-4">
                    <h3>Welcome! <span style="color: #3f3a94;"><?= $_SESSION['username'] ?></span></h3>
                        <hr>
                        <p>You are logged in using <?= $_SESSION['email'] ?></p>
                        <div class="clear-fix mb-4"></div>

                        <?php
                        $conn = mysqli_connect("localhost", "root", "", "capstone");

// Check if the connection was successful
if (!$conn) {
    // If connection fails, display an error message and exit
    echo "Problem in database connection! Contact administrator! Error: " . mysqli_connect_error();
    exit(); // Exit the script to prevent further execution
} else {
    // If connection is successful, proceed with the queries

    // First query for the first chart
    $sql1 = "SELECT category, SUM(quantity) AS total_quantity FROM mooeinventory WHERE inventoryTypeID = 1 AND inventorySubTypeID = 2 GROUP BY category";
    $result1 = mysqli_query($conn, $sql1);
    
    $sql2 = "SELECT category, SUM(quantity) AS total_quantity FROM mooeinventory WHERE inventoryTypeID = 1 AND inventorySubTypeID = 3 GROUP BY category";
    $result2 = mysqli_query($conn, $sql2);
    
    $sql3 = "SELECT category, SUM(quantity) AS total_quantity FROM depedinventory WHERE inventoryTypeID = 2 AND inventorySubTypeID = 2 GROUP BY category";
    $result3 = mysqli_query($conn, $sql3);
    
    $sql4 = "SELECT category, SUM(quantity) AS total_quantity FROM depedinventory WHERE inventoryTypeID = 2 AND inventorySubTypeID = 3 GROUP BY category";
    $result4 = mysqli_query($conn, $sql4);
    
    $sql5 = "SELECT category, SUM(quantity) AS total_quantity FROM otherinventory WHERE inventoryTypeID = 3 AND inventorySubTypeID = 2 GROUP BY category";
    $result5 = mysqli_query($conn, $sql5);
    
    $sql6 = "SELECT category, SUM(quantity) AS total_quantity FROM otherinventory WHERE inventoryTypeID = 3 AND inventorySubTypeID = 3 GROUP BY category";
    $result6 = mysqli_query($conn, $sql6);

    $sql7 = "SELECT category, SUM(quantity) AS total_quantity FROM  otherinventory WHERE inventoryTypeID = 3 AND inventorySubTypeID = 2  GROUP BY category";
    $result7 = mysqli_query($conn, $sql7);

    // Second query for the second chart
    $sql8 = "SELECT category, SUM(quantity) AS total_quantity FROM otherinventory WHERE inventoryTypeID = 3 AND inventorySubTypeID = 2  GROUP BY category";
    $result8 = mysqli_query($conn, $sql8);

    // Third query for the third chart
    $sql9 = "SELECT category, SUM(quantity) AS total_quantity FROM otherinventory WHERE inventoryTypeID = 3 AND inventorySubTypeID = 3  GROUP BY category";
    $result9 = mysqli_query($conn, $sql9);

    // Check if the queries were successful
    if ($result1 && $result2 && $result3) {
        // Initialize arrays to store product categorys and quantities for each chart
        $categoryNames1 = array();
        $quantity1 = array();
        $categoryNames2 = array();
        $quantity2 = array();
        $categoryNames3 = array();
        $quantity3 = array();
        $categoryNames4 = array();
        $quantity4 = array();
        $categoryNames5 = array();
        $quantity5 = array();
        $categoryNames6 = array();
        $quantity6 = array();
        $categoryNames7 = array();
        $quantity7 = array();
        $categoryNames8 = array();
        $quantity8 = array();
        $categoryNames9 = array();
        $quantity9 = array();

        // Fetch data from the result sets of each query
        while ($row = mysqli_fetch_array($result1)) {
            $categoryNames1[] = $row['category'];
            $quantity1[] = $row['total_quantity'];
        }
        while ($row = mysqli_fetch_array($result2)) {
            $categoryNames2[] = $row['category'];
            $quantity2[] = $row['total_quantity'];
        }
        while ($row = mysqli_fetch_array($result3)) {
            $categoryNames3[] = $row['category'];
            $quantity3[] = $row['total_quantity'];
        }
        while ($row = mysqli_fetch_array($result4)) {
            $categoryNames4[] = $row['category'];
            $quantity4[] = $row['total_quantity'];
        }
        while ($row = mysqli_fetch_array($result5)) {
            $categoryNames5[] = $row['category'];
            $quantity5[] = $row['total_quantity'];
        }
        while ($row = mysqli_fetch_array($result6)) {
            $categoryNames6[] = $row['category'];
            $quantity6[] = $row['total_quantity'];
        }
        while ($row = mysqli_fetch_array($result7)) {
            $categoryNames7[] = $row['category'];
            $quantity7[] = $row['total_quantity'];
        }
        while ($row = mysqli_fetch_array($result8)) {
            $categoryNames8[] = $row['category'];
            $quantity8[] = $row['total_quantity'];
        }
        while ($row = mysqli_fetch_array($result9)) {
            $categoryNames9[] = $row['category'];
            $quantity9[] = $row['total_quantity'];
        }
    } else {
        // If any query fails, display an error message
        echo "Error retrieving data from database: " . mysqli_error($con);
    } 
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Graph</title> 
    <style>
        .chart-container {
            width: 30%;
            display: inline-block;
            vertical-align: top;
            margin: 10px;
            margin-left: 22px;
            margin-bottom: 20px; /* Added margin between each row */
            border: 1px solid #ccc; /* Add border */
            border-radius: 5px; /* Optional: Add border radius for rounded corners */
            padding: 10px; /* Add padding */
        }

        h2 {
            text-align: center;
        }
    </style>
</head>
<body>
    <!-- DEPED CHART -->
    <h2>MOOE</h2>
    <!-- First copy of the bar chart -->
    <div class="chart-container">
        <!-- <h2 class="page-header">DEPED</h2> -->
        <div style="text-align: center;">SUPPLY</div>
        <canvas id="chartjs_bar1"></canvas> 
    </div>    
    <!-- Second copy of the bar chart -->
    <div class="chart-container">
        <!-- <h2 class="page-header">DEPED</h2> -->
        <div style="text-align: center;">SEM-EXPENDABLE</div>
        <canvas id="chartjs_bar2"></canvas> 
    </div>    

    <!-- Third copy of the bar chart -->
    <div class="chart-container">
        <!-- <h2 class="page-header">DEPED</h2> -->
        <div style="text-align: center;">PROPERTY, PLANT, AND EQUIPMENT</div>
        <canvas id="chartjs_bar3"></canvas> 
    </div> 
    
<!-- MOOE CHART -->
    <h2>DEPED</h2>
    <!-- First copy of the bar chart -->
    <div class="chart-container">
        <!-- <h2 class="page-header">DEPED</h2> -->
        <div style="text-align: center;">SEMI-EXPENDABLE</div>
        <canvas id="chartjs_bar4"></canvas> 
    </div>    

    <!-- Second copy of the bar chart -->
    <div class="chart-container">
        <!-- <h2 class="page-header">DEPED</h2> -->
        <div style="text-align: center;">SUPPLY</div>
        <canvas id="chartjs_bar5"></canvas> 
    </div>    

    <!-- Third copy of the bar chart -->
    <div class="chart-container">
        <!-- <h2 class="page-header">DEPED</h2> -->
        <div style="text-align: center;">PROPERTY, PLANT, AND EQUIPMENT</div>
        <canvas id="chartjs_bar6"></canvas> 
    </div>
   
       <!--CUSTODIAN CHART  -->
    <h2>OTHERS</h2>
    <!-- First copy of the bar chart -->
    <div class="chart-container">
        <!-- <h2 class="page-header">DEPED</h2> -->
        <div style="text-align: center;">SEMI-EXPENDABLE</div>
        <canvas id="chartjs_bar7"></canvas> 
    </div>    

    <!-- Second copy of the bar chart -->
    <div class="chart-container">
        <!-- <h2 class="page-header">DEPED</h2> -->
        <div style="text-align: center;">SUPPLY</div>
        <canvas id="chartjs_bar8"></canvas> 
    </div>    

    <!-- Third copy of the bar chart -->
    <div class="chart-container">
        <!-- <h2 class="page-header">DEPED</h2> -->
        <div style="text-align: center;">PROPERTY, PLANT, AND EQUIPMENT</div>
        <canvas id="chartjs_bar9"></canvas> 
    </div>   
</body>
</html>

<script src="//code.jquery.com/jquery-1.9.1.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
<script type="text/javascript">
    // JavaScript for the first chart
    var ctx1 = document.getElementById("chartjs_bar1").getContext('2d');
    var myChart1 = new Chart(ctx1, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($categoryNames1); ?>,
            datasets: [{
                backgroundColor: [
                    "#5969ff",
                    "#ff407b",
                    "#25d5f2",
                    "#ffc750",
                    "#2ec551",
                    "#7040fa",
                    "#ff004e"
                ],
                data: <?php echo json_encode($quantity1); ?>,
            }]
        },
        options: {
            legend: {
                display: true,
                position: 'bottom',
                labels: {
                    fontColor: '#71748d',
                    fontFamily: 'Circular Std Book',
                    fontSize: 14,
                }
            }
        }
    });

    // JavaScript for the second chart
    var ctx2 = document.getElementById("chartjs_bar2").getContext('2d');
    var myChart2 = new Chart(ctx2, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($categoryNames2); ?>,
            datasets: [{
                backgroundColor: [
                    "#5969ff",
                    "#ff407b",
                    "#25d5f2",
                    "#ffc750",
                    "#2ec551",
                    "#7040fa",
                    "#ff004e"
                ],
                data: <?php echo json_encode($quantity2); ?>,
            }]
        },
        options: {
            legend: {
                display: true,
                position: 'bottom',
                labels: {
                    fontColor: '#71748d',
                    fontFamily: 'Circular Std Book',
                    fontSize: 14,
                }
            }
        }
    });

    // JavaScript for the third chart
    var ctx3 = document.getElementById("chartjs_bar3").getContext('2d');
    var myChart3 = new Chart(ctx3, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($categoryNames3); ?>,
            datasets: [{
                backgroundColor: [
                    "#5969ff",
                    "#ff407b",
                    "#25d5f2",
                    "#ffc750",
                    "#2ec551",
                    "#7040fa",
                    "#ff004e"
                ],
                data: <?php echo json_encode($quantity3); ?>,
            }]
        },
        options: {
            legend: {
                display: true,
                position: 'bottom',
                labels: {
                    fontColor: '#71748d',
                    fontFamily: 'Circular Std Book',
                    fontSize: 14,
                }
            }
        }
    });
    // JavaScript for the fourth chart
    var ctx3 = document.getElementById("chartjs_bar4").getContext('2d');
    var myChart3 = new Chart(ctx3, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($categoryNames4); ?>,
            datasets: [{
                backgroundColor: [
                    "#5969ff",
                    "#ff407b",
                    "#25d5f2",
                    "#ffc750",
                    "#2ec551",
                    "#7040fa",
                    "#ff004e"
                ],
                data: <?php echo json_encode($quantity4); ?>,
            }]
        },
        options: {
            legend: {
                display: true,
                position: 'bottom',
                labels: {
                    fontColor: '#71748d',
                    fontFamily: 'Circular Std Book',
                    fontSize: 14,
                }
            }
        }
    });
        // JavaScript for the fifth chart
        var ctx3 = document.getElementById("chartjs_bar5").getContext('2d');
    var myChart3 = new Chart(ctx3, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($categoryNames5); ?>,
            datasets: [{
                backgroundColor: [
                    "#5969ff",
                    "#ff407b",
                    "#25d5f2",
                    "#ffc750",
                    "#2ec551",
                    "#7040fa",
                    "#ff004e"
                ],
                data: <?php echo json_encode($quantity5); ?>,
            }]
        },
        options: {
            legend: {
                display: true,
                position: 'bottom',
                labels: {
                    fontColor: '#71748d',
                    fontFamily: 'Circular Std Book',
                    fontSize: 14,
                }
            }
        }
    });
        // JavaScript for the sixth chart
        var ctx3 = document.getElementById("chartjs_bar6").getContext('2d');
    var myChart3 = new Chart(ctx3, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($categoryNames6); ?>,
            datasets: [{
                backgroundColor: [
                    "#5969ff",
                    "#ff407b",
                    "#25d5f2",
                    "#ffc750",
                    "#2ec551",
                    "#7040fa",
                    "#ff004e"
                ],
                data: <?php echo json_encode($quantity6); ?>,
            }]
        },
        options: {
            legend: {
                display: true,
                position: 'bottom',
                labels: {
                    fontColor: '#71748d',
                    fontFamily: 'Circular Std Book',
                    fontSize: 14,
                }
            }
        }
    });
        // JavaScript for the seventh chart
        var ctx3 = document.getElementById("chartjs_bar7").getContext('2d');
    var myChart3 = new Chart(ctx3, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($categoryNames7); ?>,
            datasets: [{
                backgroundColor: [
                    "#5969ff",
                    "#ff407b",
                    "#25d5f2",
                    "#ffc750",
                    "#2ec551",
                    "#7040fa",
                    "#ff004e"
                ],
                data: <?php echo json_encode($quantity7); ?>,
            }]
        },
        options: {
            legend: {
                display: true,
                position: 'bottom',
                labels: {
                    fontColor: '#71748d',
                    fontFamily: 'Circular Std Book',
                    fontSize: 14,
                }
            }
        }
    });
        // JavaScript for the eight chart
        var ctx3 = document.getElementById("chartjs_bar8").getContext('2d');
    var myChart3 = new Chart(ctx3, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($categoryNames8); ?>,
            datasets: [{
                backgroundColor: [
                    "#5969ff",
                    "#ff407b",
                    "#25d5f2",
                    "#ffc750",
                    "#2ec551",
                    "#7040fa",
                    "#ff004e"
                ],
                data: <?php echo json_encode($quantity8); ?>,
            }]
        },
        options: {
            legend: {
                display: true,
                position: 'bottom',
                labels: {
                    fontColor: '#71748d',
                    fontFamily: 'Circular Std Book',
                    fontSize: 14,
                }
            }
        }
    });
        // JavaScript for the nine chart
        var ctx3 = document.getElementById("chartjs_bar9").getContext('2d');
    var myChart3 = new Chart(ctx3, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($categoryNames9); ?>,
            datasets: [{
                backgroundColor: [
                    "#5969ff",
                    "#ff407b",
                    "#25d5f2",
                    "#ffc750",
                    "#2ec551",
                    "#7040fa",
                    "#ff004e"
                ],
                data: <?php echo json_encode($quantity9); ?>,
            }]
        },
        options: {
            legend: {
                display: true,
                position: 'bottom',
                labels: {
                    fontColor: '#71748d',
                    fontFamily: 'Circular Std Book',
                    fontSize: 14,
                }
            }
        }
    });
</script>

                    </div>
                </div>
                
            </div>
        </div>
    </div>
    </main>





            </div>
        </div>
    </div>
    <!-- /#page-content-wrapper -->
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        var el = document.getElementById("wrapper");
        var toggleButton = document.getElementById("menu-toggle");

        toggleButton.onclick = function () {
            el.classList.toggle("toggled");
        };
    </script>
</body>

</html>