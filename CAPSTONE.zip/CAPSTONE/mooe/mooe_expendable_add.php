<?php
	session_start();
	include_once('../connection/connection.php');

	if(isset($_POST['expendableadd'])){
		$quantity = $_POST['quantity'];
		$unit = $_POST['unit'];
		$unitCost = $_POST['unitCost'];
		$totalCost = $_POST['totalCost'];
		$category = $_POST['category'];
		$inventoryNo = $_POST['inventoryNo'];
		$sql = "INSERT INTO mooeinventory (inventoryTypeID,inventorySubTypeID,quantity, unit, unitCost, totalCost, category, inventoryNo) 
        VALUES (1, 2,'$quantity', '$unit', $unitCost', '$totalCost', '$category', '$inventoryNo')";

		
		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'Item added successfully';
		}
		
		else{
			$_SESSION['error'] = 'Something went wrong while adding';
		}
	}
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}

	header('location: mooe_expendable_index.php');
?>