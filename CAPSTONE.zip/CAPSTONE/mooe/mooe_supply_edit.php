<?php
	session_start();
	include_once('../connection/connection.php');

	if(isset($_POST['mooesupplyedit'])){
		$mooeID = $_POST['mooeID'];
		$stockNo = $_POST['stockNo'];
		$unit = $_POST['unit'];
		$category = $_POST['category'];
		$quantity = $_POST['quantity'];
		$stockAvailable = $_POST['stockAvailable'];
		$remarks = $_POST['reamarks'];
		$sql = "UPDATE mooeinventory SET stockNo = '$stockNo', unit = '$unit', category = '$category', quantity = '$quantity', stockAvailable = '$stockAvailable', remarks = '$remarks' WHERE mooeID = '$mooeID'";

		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'Item updated successfully';
		}
		else{
			$_SESSION['error'] = 'Something went wrong in updating item';
		}
	}
	else{
		$_SESSION['error'] = 'Select item to edit first';
	}

	header('location: mooe_supply_index.php');

?>