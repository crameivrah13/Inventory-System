<?php
	session_start();
	include_once('../connection/connection.php');

	if(isset($_POST['mooeedit'])){
		$mooeID = $_POST['mooeID'];
		$quantity = $_POST['quantity'];
		$unit = $_POST['unit'];
		$unitCost = $_POST['unitCost'];
		$totalCost = $_POST['totalCost'];
		$description = $_POST['description'];
		$inventoryNo = $_POST['inventoryNo'];
		$estimatedLife = $_POST['estimatedLife'];
		$sql = "UPDATE mooeinventory SET quantity = '$quantity', unit = '$unit', unitCost = '$unitCost', totalCost = '$totalCost', description = '$description', inventoryNo = '$inventoryNo', estimatedLife = '$estimatedLife' WHERE mooeID = '$mooeID'";

		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'Item updated successfully';
		}
		
		else{
			$_SESSION['error'] = 'Something went wrong in updating item';
		}
	}
	else{
		$_SESSION['error'] = 'Select item to edit first';
	}

	header('location: mooe_expendable_index.php');

?>