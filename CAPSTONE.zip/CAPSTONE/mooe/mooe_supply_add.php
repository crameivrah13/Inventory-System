<?php
	session_start();
	include_once('../connection/connection.php');

	if(isset($_POST['mooesupplyadd'])){
		$stockNo = $_POST['stockNo'];
		$unit = $_POST['unit'];
		$category = $_POST['category'];
		$quantity = $_POST['quantity'];
		$stockAvailable = $_POST['stockAvailable'];
		$remarks = $_POST['remarks'];
		$sql = "INSERT INTO mooeinventory (inventoryTypeID,inventorySubTypeID, stockNo, unit, category, quantity, stockAvailable, remarks) VALUES (1, 1,'$stockNo', '$unit', '$category', '$quantity', '$stockAvailable', '$remarks')";

		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'Item added successfully';
		}
		
		else{
			$_SESSION['error'] = 'Something went wrong while adding';
		}
	}
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}

	header('location: mooe_supply_index.php');
?>