<?php
	session_start();
	include_once('../connection/connection.php');

	if(isset($_POST['insert'])){
		$teachersID = $_POST['teachersID'];
		$sql = "INSERT INTO inventory (inventoryTypeID,inventorySubTypeID,teachersID) VALUES (1, 3,'$teachersID')";

		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'Item added successfully';
		}
		
		else{
			$_SESSION['error'] = 'Something went wrong while adding';
		}
	}
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}

	header('location: mooe_equipment_index.php');
?>