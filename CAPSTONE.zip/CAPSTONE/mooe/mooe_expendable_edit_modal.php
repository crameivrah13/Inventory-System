<!-- Edit -->
<!-- Edit -->
<div class="modal fade" id="editModal<?php echo $row['mooeID']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
			<button type="button" class="close" data-bs-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Edit Item</h4></center>
            </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <form method="POST" action="mooe_expendable_index.php">
                        <input type="hidden" class="form-control" name="mooeID" value="<?php echo $row['mooeID']; ?>">
                        <div class="row form-group">
					<div class="col-sm-4">
						<label class="control-label modal-label">Quantity:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="quantity" value="<?php echo $row['quantity']; ?>">
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Unit:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="unit" value="<?php echo $row['unit']; ?>">
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Unit Cost:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="unitCost" value="<?php echo $row['unitCost']; ?>">
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Total Cost:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="totalCost" value="<?php echo $row['totalCost']; ?>">
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Description:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="category" value="<?php echo $row['category']; ?>">
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Inventory Item No:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="inventoryNo" value="<?php echo $row['inventoryNo']; ?>">
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Estimated Useful Life:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="estimatedLife" value="<?php echo $row['estimatedLife']; ?>">
					</div>
				</div>
                
                </div>
            </div>
			<div class="modal-footer">
			<button type="button" class="btn btn-default" data-bs-dismiss="modal">
                    <span class="glyphicon glyphicon-remove"></span> Cancel
                </button>
    <button type="submit" name="mooeedit" class="btn btn-success">
        Update
    </button>
</div>

			</form>
        </div>
    </div>
</div>

