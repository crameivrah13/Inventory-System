<!-- Edit -->
<div class="modal fade" id="mooesupplyedit<?php echo $row['mooeID']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
			<button type="button" class="close" data-bs-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Edit Item</h4></center>
            </div>
            <div class="modal-body">
			<div class="container-fluid">
			<form method="POST" action="mooe_equipment_edit.php">
			<input type="hidden" class="form-control" name="mooeID" value="<?php echo $row['mooeID']; ?>">
			   <div class="row form-group">
					<div class="col-sm-4">
						<label class="control-label modal-label">Stock No:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="stockNo" value="<?php echo $row['stockNo']; ?>">
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Unit:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="unit" value="<?php echo $row['unit']; ?>">
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Description:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="category" value="<?php echo $row['category']; ?>">
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Quantity:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="quantity" value="<?php echo $row['quantity']; ?>">
					</div>
				</div>
				<div class="row form-group mt-2">
    <div class="col-sm-4">
        <label class="control-label modal-label">Stock Available:</label>
    </div>
    <div class="col-sm-8">
        <div class="form-check">
            <input class="form-check-input" type="radio" name="stockAvailable" id="stockAvailableYes" value="yes" <?php echo ($row['stockAvailable'] == 'yes') ? 'checked' : ''; ?>>
            <label class="form-check-label" for="stockAvailableYes">
                Yes
            </label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="stockAvailable" id="stockAvailableNo" value="no" <?php echo ($row['stockAvailable'] == 'no') ? 'checked' : ''; ?>>
            <label class="form-check-label" for="stockAvailableNo">
                No
            </label>
        </div>
    </div>
</div>

				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Remarks:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="remarks" value="<?php echo $row['remarks']; ?>">
					</div>
				</div>
            </div> 
			</div>
            <div class="modal-footer">
			<button type="button" class="btn btn-default" data-bs-dismiss="modal">
                    <span class="glyphicon glyphicon-remove"></span> Cancel
                </button>
                <button type="submit" name="moeesupplyedit" class="btn btn-success">
                Update
		</form>
            </div>

        </div>
    </div>
</div>
