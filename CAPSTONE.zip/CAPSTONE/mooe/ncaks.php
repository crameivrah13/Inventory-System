<?php
include_once('../connection/connection.php');

// I-include ang modal
include('mooe_equipment_add_modal.php');

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Award Teacher Transfer</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<div class="container mt-5">
    <div class="card">
        <div class="card-header">
            <h4>Award Teacher Transfer</h4>
        </div>
        <div class="card-body">
            <form method="POST" action="transferaccount.php">
                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Teacher:</label>
                    <div class="col-sm-8">
                        <select class="form-control" name="name">
                            <?php
                            $sql = "SELECT * FROM teacher";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $teacherName = $row['fname'] . ' ' . $row['mname'] . ' ' . $row['lname'];
                                    echo "<option value='" . $row['teachersID'] . "'>" . $teacherName . "</option>";
                                }
                            }
                            ?>
                        </select>
                    </div>
                </div>

                <!-- Quantity -->
                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Quantity:</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" name="quantity" value="">
                    </div>
                </div>

                <!-- Unit -->
                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Unit:</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" name="unit" value="" readonly>
                    </div>
                </div>

                <!-- Unit Cost -->
                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Unit Cost:</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" name="unitCost" value="" readonly>
                    </div>
                </div>

                <!-- Total Cost -->
                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Total Cost:</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" name="totalCost" value="" readonly>
                    </div>
                </div>

                <!-- Description -->
                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Description:</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" name="description" value="" readonly>
                    </div>
                </div>

                <!-- Inventory Item No -->
                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Inventory Item No:</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" name="inventoryNo" value="" readonly>
                    </div>
                </div>

                <!-- Source Of Funding -->
                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Source Of Funding:</label>
                    <div class="col-sm-8">
                        <input type="text" class="form-control" name="source" required>
                    </div>
                </div>

                <!-- Remarks -->
                <div class="form-group row">
                    <label class="col-sm-4 col-form-label">Remarks:</label>
                    <div class="col-sm-8">
                        <select class="form-control" name="remarks" required>
                            <option value="Functional">Functional</option>
                            <option value="Non-functional">Non-functional</option>
                        </select>
                    </div>
                </div>

                <!-- Submit Button -->
                <div class="form-group row mt-3">
                    <div class="col-sm-12">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>
