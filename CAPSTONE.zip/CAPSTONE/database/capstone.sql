-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 12, 2024 at 02:53 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `capstone`
--

-- --------------------------------------------------------

--
-- Table structure for table `accountability`
--

CREATE TABLE `accountability` (
  `accountID` int(11) NOT NULL,
  `inventoryID` int(11) NOT NULL,
  `fromteacherID` varchar(50) NOT NULL,
  `toteacherID` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `depedinventory`
--

CREATE TABLE `depedinventory` (
  `depedID` int(11) NOT NULL,
  `inventoryTypeID` int(11) NOT NULL,
  `inventorySubTypeID` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `inventoryNo` int(11) NOT NULL,
  `unitCost` double NOT NULL,
  `totalCost` double NOT NULL,
  `dateAcquired` date NOT NULL DEFAULT current_timestamp(),
  `estimatedLife` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `depedinventory`
--

INSERT INTO `depedinventory` (`depedID`, `inventoryTypeID`, `inventorySubTypeID`, `quantity`, `unit`, `category`, `inventoryNo`, `unitCost`, `totalCost`, `dateAcquired`, `estimatedLife`) VALUES
(1, 2, 3, 50, 'unit1', 'tv', 27327, 10000, 0, '2024-04-05', ''),
(2, 2, 2, 8, 'unit', 'Smart Tv', 2372, 10000, 500000, '2024-04-10', '5 years');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `inventoryID` int(11) NOT NULL,
  `isTransfered` int(11) NOT NULL,
  `inventoryTypeID` int(11) NOT NULL,
  `teachersID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`inventoryID`, `isTransfered`, `inventoryTypeID`, `teachersID`) VALUES
(1, 0, 3, 1),
(2, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `inventorysubtype`
--

CREATE TABLE `inventorysubtype` (
  `inventorySubTypeID` int(11) NOT NULL,
  `description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventorysubtype`
--

INSERT INTO `inventorysubtype` (`inventorySubTypeID`, `description`) VALUES
(1, 'Supply'),
(2, 'Semi-Expendable'),
(3, 'Property, Plant and Equipment');

-- --------------------------------------------------------

--
-- Table structure for table `inventorytype`
--

CREATE TABLE `inventorytype` (
  `inventoryTypeID` int(11) NOT NULL,
  `description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventorytype`
--

INSERT INTO `inventorytype` (`inventoryTypeID`, `description`) VALUES
(1, 'Maintenance and other Operating Expense'),
(2, 'Department of Education'),
(3, 'Others');

-- --------------------------------------------------------

--
-- Table structure for table `mooeinventory`
--

CREATE TABLE `mooeinventory` (
  `mooeID` int(11) NOT NULL,
  `inventoryTypeID` int(11) NOT NULL,
  `inventorySubTypeID` int(11) NOT NULL,
  `inventoryNo` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `unitCost` double NOT NULL,
  `totalCost` double NOT NULL,
  `estimatedLife` varchar(50) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `dateAcquired` date NOT NULL DEFAULT current_timestamp(),
  `amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mooeinventory`
--

INSERT INTO `mooeinventory` (`mooeID`, `inventoryTypeID`, `inventorySubTypeID`, `inventoryNo`, `quantity`, `category`, `unitCost`, `totalCost`, `estimatedLife`, `unit`, `dateAcquired`, `amount`) VALUES
(1, 1, 2, 9521102, 2, 'Smart Tv', 123, -1107, '', '', '2024-04-08', 0),
(2, 1, 2, 9521102, 12, 'Smart Tv', 123, 123, '', '', '2024-04-08', 0),
(3, 1, 3, 952110, 9, 'Smart Tv', 0, 0, '', 'unit', '2024-04-05', 0),
(4, 1, 3, 952110111, 9, 'Smart Tv', 0, 0, '', 'unit', '2024-04-03', 0),
(5, 1, 3, 8227327, 50, 'LAPTOP', 0, 0, '', 'unit1', '2024-04-05', 10000),
(6, 1, 3, 8227327, 50, 'LAPTOP', 10000, 0, '', 'unit1', '2024-04-05', 0);

-- --------------------------------------------------------

--
-- Table structure for table `otherinventory`
--

CREATE TABLE `otherinventory` (
  `otherID` int(11) NOT NULL,
  `inventoryTypeID` int(11) NOT NULL,
  `inventorySubTypeID` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `inventoryNo` int(11) NOT NULL,
  `unitCost` double NOT NULL,
  `totalCost` double NOT NULL,
  `dateAcquired` date NOT NULL DEFAULT current_timestamp(),
  `estimatedLife` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `otherinventory`
--

INSERT INTO `otherinventory` (`otherID`, `inventoryTypeID`, `inventorySubTypeID`, `quantity`, `unit`, `category`, `inventoryNo`, `unitCost`, `totalCost`, `dateAcquired`, `estimatedLife`) VALUES
(1, 3, 1, 23, 'box', 'BondPaper', 12831932, 0, 0, '2024-04-08', ''),
(5, 3, 2, 23, 'pieces', 'Pencil', 12831932, 0, 0, '2024-04-08', ''),
(6, 3, 2, 7, 'unit', 'Smart Tv', 2372, 10000, 450000, '2024-04-10', '5 years');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teachersID` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `mname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teachersID`, `fname`, `mname`, `lname`) VALUES
(1, 'Lyca', 'Mae', 'Santiago'),
(2, 'Marc', 'V', 'Lumabe'),
(4, 'Lloyd', 'Yanson', 'Mayores'),
(5, 'kylle', 'maniego', 'gimeno'),
(6, 'OLIVIA', 'w', 'MAYORES');

-- --------------------------------------------------------

--
-- Table structure for table `teacheraccountability`
--

CREATE TABLE `teacheraccountability` (
  `accountabilityID` int(11) NOT NULL,
  `inventoryTypeID` int(11) NOT NULL,
  `inventorySubTypeID` int(11) NOT NULL,
  `inventoryNo` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `sourceOfFunding` varchar(50) NOT NULL,
  `unitCost` double NOT NULL,
  `totalCost` double NOT NULL,
  `dateOfIssue` date NOT NULL DEFAULT current_timestamp(),
  `remarks` varchar(50) NOT NULL,
  `teachersID` int(11) NOT NULL,
  `amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teacheraccountability`
--

INSERT INTO `teacheraccountability` (`accountabilityID`, `inventoryTypeID`, `inventorySubTypeID`, `inventoryNo`, `quantity`, `category`, `sourceOfFunding`, `unitCost`, `totalCost`, `dateOfIssue`, `remarks`, `teachersID`, `amount`) VALUES
(87, 0, 0, 9521102, 5, 'Smart Tv', 'none', 123, 615, '2024-04-11', 'functional', 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `teachertransaction`
--

CREATE TABLE `teachertransaction` (
  `transactionID` int(11) NOT NULL,
  `transferFrom` varchar(50) NOT NULL,
  `transferTo` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `inventoryNo` int(11) NOT NULL,
  `transferDate` date NOT NULL DEFAULT current_timestamp(),
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachertransaction`
--

INSERT INTO `teachertransaction` (`transactionID`, `transferFrom`, `transferTo`, `category`, `inventoryNo`, `transferDate`, `quantity`) VALUES
(17, '1', '1', 'LAPTOP', 8227327, '2024-04-09', 0),
(18, '1', '2', 'Smart Tv', 9521102, '2024-04-11', 0),
(19, '1', '6', 'Smart Tv', 9521102, '2024-04-11', 2),
(20, '2', '5', 'Smart Tv', 9521102, '2024-04-11', 5);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `otp` varchar(6) DEFAULT NULL,
  `otp_expiry` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `otp`, `otp_expiry`) VALUES
(1, 'Lloyd Mayores', 'lloydmayores761@gmail.com', '$2y$10$JVkF2Uka7.PYwhWi0dfjyO4SFBzASjMHNiVIYSjSnfe8TA13aMDiy', '113761', '2024-04-11 13:51:31'),
(2, 'Dave Kylle', 'mayoreslloyd@gmail.com', '$2y$10$3QY0c3aeXjcKzIJzMIyJN.VdmnRlRG/XavlUOn2ypEaU9kt50eO.G', '927437', '2024-03-30 06:23:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accountability`
--
ALTER TABLE `accountability`
  ADD PRIMARY KEY (`accountID`);

--
-- Indexes for table `depedinventory`
--
ALTER TABLE `depedinventory`
  ADD PRIMARY KEY (`depedID`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`inventoryID`);

--
-- Indexes for table `inventorysubtype`
--
ALTER TABLE `inventorysubtype`
  ADD PRIMARY KEY (`inventorySubTypeID`);

--
-- Indexes for table `inventorytype`
--
ALTER TABLE `inventorytype`
  ADD PRIMARY KEY (`inventoryTypeID`);

--
-- Indexes for table `mooeinventory`
--
ALTER TABLE `mooeinventory`
  ADD PRIMARY KEY (`mooeID`);

--
-- Indexes for table `otherinventory`
--
ALTER TABLE `otherinventory`
  ADD PRIMARY KEY (`otherID`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teachersID`);

--
-- Indexes for table `teacheraccountability`
--
ALTER TABLE `teacheraccountability`
  ADD PRIMARY KEY (`accountabilityID`);

--
-- Indexes for table `teachertransaction`
--
ALTER TABLE `teachertransaction`
  ADD PRIMARY KEY (`transactionID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accountability`
--
ALTER TABLE `accountability`
  MODIFY `accountID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `depedinventory`
--
ALTER TABLE `depedinventory`
  MODIFY `depedID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `inventoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `inventorysubtype`
--
ALTER TABLE `inventorysubtype`
  MODIFY `inventorySubTypeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `inventorytype`
--
ALTER TABLE `inventorytype`
  MODIFY `inventoryTypeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mooeinventory`
--
ALTER TABLE `mooeinventory`
  MODIFY `mooeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `otherinventory`
--
ALTER TABLE `otherinventory`
  MODIFY `otherID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `teachersID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `teacheraccountability`
--
ALTER TABLE `teacheraccountability`
  MODIFY `accountabilityID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `teachertransaction`
--
ALTER TABLE `teachertransaction`
  MODIFY `transactionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
