<?php
	session_start();
	include_once('../connection/connection.php');

	if(isset($_POST['equipadd'])){
		$quantity = $_POST['quantity'];
		$unit = $_POST['unit'];
		$category = $_POST['category'];
		$inventoryNo = $_POST['inventoryNo'];
		$dateAcquired = $_POST['dateAcquired'];
		$amount = $_POST['amount'];
		$sql = "INSERT INTO inventory (inventoryTypeID, inventorySubTypeID, quantity, unit, category, inventoryNo, dateAcquired, amount) VALUES (3, 3, '$quantity', '$unit', '$category', '$inventoryNo', '$dateAcquired', '$amount')";

		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'Item added successfully';
		}
		
		else{
			$_SESSION['error'] = 'Something went wrong while adding';
		}
	}
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}

	header('location: others_equipment_index.php');
?>