<?php
session_start();
include_once('../connection/connection.php');

if(isset($_POST['otheradd'])){
    $quantity = $_POST['quantity'];
    $unit = $_POST['unit'];
    $unitCost = $_POST['unitCost'];
    $totalCost = $_POST['totalCost'];
    $category = $_POST['category'];
    $inventoryNo = $_POST['inventoryNo'];
    $estimatedLife = $_POST['estimatedLife'];
    $sql = "INSERT INTO otherinventory (inventoryTypeID, inventorySubTypeID, quantity, unit, unitCost, totalCost, category, inventoryNo, estimatedLife) VALUES (3, 2, '$quantity', '$unit', '$unitCost', '$totalCost', '$category', '$inventoryNo', '$estimatedLife')";

    if($conn->query($sql)){
        $_SESSION['success'] = 'Item added successfully';
    } else {
        $_SESSION['error'] = 'Something went wrong while adding';
    }
} else {
    $_SESSION['error'] = 'Fill up add form first';
}

header('location: others_expendable_index.php');
?>
