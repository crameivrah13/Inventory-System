<!-- Add New -->
<div class="modal fade" id="equipnewadd" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Add New</h4></center>
            </div>
            <div class="modal-body">
			<div class="container-fluid">
			<form method="POST" action="others_equipment_add.php">
				<div class="row form-group">
					<div class="col-sm-4">
						<label class="control-label modal-label">Quantity:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="quantity" required>
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Unit:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="unit" required>
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Description:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="category" required>
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Property Number:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="inventoryNo" required>
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Date Acquired:</label>
					</div>
					<div class="col-sm-8">
						<input type="date" class="form-control" name="dateAcquired" required>
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Amount:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="unitCost" required>
					</div>
				</div>
            </div> 
			</div>
            <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal" onclick="$('#equipnewadd').modal('hide');">
      <span class="glyphicon glyphicon-remove"></span> Cancel
    <button type="submit" name="equipadd" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Save</button>
			</form>
            </div>

        </div>
    </div>
</div>