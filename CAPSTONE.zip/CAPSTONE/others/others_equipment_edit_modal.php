<!-- Edit -->
<div class="modal fade" id="equipedit<?php echo $row['otherID']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
			<button type="button" class="close" data-bs-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Edit Item</h4></center>
            </div>
            <div class="modal-body">
			<div class="container-fluid">
			<form method="POST" action="others_equipment_edit.php">
			<input type="hidden" class="form-control" name="otherID" value="<?php echo $row['otherID']; ?>">
			   <div class="row form-group">
					<div class="col-sm-4">
						<label class="control-label modal-label">Quantity:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="quantity" value="<?php echo $row['quantity']; ?>">
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Unit:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="unit" value="<?php echo $row['unit']; ?>">
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Description:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="category" value="<?php echo $row['category']; ?>">
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Property Number:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="inventoryNo" value="<?php echo $row['inventoryNo']; ?>">
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Date Acquired:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="dateAcquired" value="<?php echo $row['dateAcquired']; ?>">
					</div>
				</div>
				<div class="row form-group mt-2">
					<div class="col-sm-4">
						<label class="control-label modal-label">Amount:</label>
					</div>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="amount" value="<?php echo $row['amount']; ?>">
					</div>
				</div>
            </div> 
			</div>
            <div class="modal-footer">
			<button type="button" class="btn btn-default" data-bs-dismiss="modal">
                    <span class="glyphicon glyphicon-remove"></span> Cancel
                </button>
                <button type="submit" name="equipedit" class="btn btn-success">
                Update
		</form>
            </div>

        </div>
    </div>
</div>

<!-- Delete -->
<div class="modal fade" id="delete_<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Delete Item</h4></center>
            </div>
            <div class="modal-body">	
            	<p class="text-center">Are you sure you want to Delete</p>
				<h2 class="text-center"><?php echo $row['firstname'].' '.$row['lastname']; ?></h2>
			</div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <a href="delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Yes</a>
            </div>

        </div>
    </div>
</div>