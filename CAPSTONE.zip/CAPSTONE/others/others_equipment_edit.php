<?php
	session_start();
	include_once('../connection/connection.php');

	if(isset($_POST['equipedit'])){
		$inventoryID = $_POST['inventoryID'];
		$quantity = $_POST['quantity'];
		$unit = $_POST['unit'];
		$category = $_POST['category'];
		$inventoryNo = $_POST['inventoryNo'];
		$dateAcquired = $_POST['dateAcquired'];
		$amount = $_POST['amount'];
		$sql = "UPDATE inventory SET quantity = '$quantity', unit = '$unit', category = '$category', inventoryNo = '$inventoryNo', dateAcquired = '$dateAcquired', amount = '$amount' WHERE inventoryID = '$inventoryID'";

		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'Item updated successfully';
		}
		
		else{
			$_SESSION['error'] = 'Something went wrong in updating item';
		}
	}
	else{
		$_SESSION['error'] = 'Select item to edit first';
	}

	header('location: others_equipment_index.php');

?>