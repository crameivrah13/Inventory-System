<div class="modal fade" id="othertransfer<?php echo $row['otherID']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-bs-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">Award Item</h4>
            </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <form method="POST" action="others_transfer_equipment.php">
                        <input type="hidden" class="form-control" name="otherID" value="<?php echo $row['otherID']; ?>">
                        
                        <div class="row form-group">
                            <div class="col-sm-4">
                                <label class="control-label modal-label">Teacher:</label>
                            </div>
                            <div class="col-sm-8">
                                <select class="form-control" name="teachersID">
                                    <?php
                                    include_once('../connection/connection.php');
                                    $sql = "SELECT * FROM teacher";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                        while ($teacher = $result->fetch_assoc()) {
                                            $teacherName = $teacher['fname'] . ' ' . $teacher['mname'] . ' ' . $teacher['lname'];
                                            echo "<option value='" . $teacher['teachersID'] . "'>" . $teacherName . "</option>";
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="row form-group mt-2">
                            <div class="col-sm-4">
                                <label class="control-label modal-label">Property Number:</label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" name="inventoryNo" value="<?php echo $row['inventoryNo']; ?>" readonly>
                            </div>
                        </div>

                        <div class="row form-group mt-2">
                            <div class="col-sm-4">
                                <label class="control-label modal-label">Quantity:</label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" name="quantity" value="<?php echo $row['quantity']; ?>">
                            </div>
                        </div>

                        <div class="row form-group mt-2">
                            <div class="col-sm-4">
                                <label class="control-label modal-label">Unit:</label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" name="unit" value="<?php echo $row['unit']; ?>" readonly>
                            </div>
                        </div>

                        <div class="row form-group mt-2">
                            <div class="col-sm-4">
                                <label class="control-label modal-label">Description:</label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" name="category" value="<?php echo $row['category']; ?>" readonly>
                            </div>
                        </div>

                        <div class="row form-group mt-2">
                            <div class="col-sm-4">
                                <label class="control-label modal-label">Source of Funding:</label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" name="sourceOfFunding">
                            </div>
                        </div>

                        <div class="row form-group mt-2">
                            <div class="col-sm-4">
                                <label class="control-label modal-label">Unit Cost:</label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" name="unitCost" value="<?php echo $row['unitCost']; ?>" readonly>
                            </div>
                        </div>

                        <div class="row form-group mt-2">
                            <div class="col-sm-4">
                                <label class="control-label modal-label">Total Cost:</label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" name="totalCost">
                            </div>
                        </div>

                        <div class="row form-group mt-2">
                            <div class="col-sm-4">
                                <label class="control-label modal-label">Date of Issue:</label>
                            </div>
                            <div class="col-sm-8">
                                <input type="date" class="form-control" name="dateOfIssue">
                            </div>
                        </div>
                        <div class="row form-group mt-2">
    <div class="col-sm-4">
        <label class="control-label modal-label">Remarks:</label>
    </div>
    <div class="col-sm-8">
        <select class="form-control" name="remarks">
            <option value="functional">Functional</option>
            <option value="non-functional">Non-Functional</option>
        </select>
    </div>
</div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-bs-dismiss="modal">
                                <span class="glyphicon glyphicon-remove"></span> Cancel
                            </button>
                            <button type="submit" name="moeeequipedit" class="btn btn-success">
                                Award
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="othertransfer2<?php echo $row['otherID']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-bs-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">Award Item</h4>
            </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <form method="POST" action="others_transfer_expendable.php">
                        <input type="hidden" class="form-control" name="otherID" value="<?php echo $row['otherID']; ?>">
                        
                        <div class="row form-group">
                            <div class="col-sm-6">
                                <label class="control-label modal-label">Teacher:</label>
                            </div>
                            <div class="col-sm-6">
                                <select class="form-control" name="teachersID">
                                    <?php
                                    include_once('../connection/connection.php');
                                    $sql = "SELECT * FROM teacher";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                        while ($teacher = $result->fetch_assoc()) {
                                            $teacherName = $teacher['fname'] . ' ' . $teacher['mname'] . ' ' . $teacher['lname'];
                                            echo "<option value='" . $teacher['teachersID'] . "'>" . $teacherName . "</option>";
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="row form-group mt-2">
                            <div class="col-sm-6">
                                <label class="control-label modal-label">Inventory Number:</label>
                            </div>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="inventoryNo" value="<?php echo $row['inventoryNo']; ?>" readonly>
                            </div>
                        </div>

                        <div class="row form-group mt-2">
                            <div class="col-sm-6">
                                <label class="control-label modal-label">Quantity:</label>
                            </div>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="quantity" value="<?php echo $row['quantity']; ?>">
                            </div>
                        </div>

                        <div class="row form-group mt-2">
                            <div class="col-sm-6">
                                <label class="control-label modal-label">Description:</label>
                            </div>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="category" value="<?php echo $row['category']; ?>" readonly>
                            </div>
                        </div>

                        <div class="row form-group mt-2">
                            <div class="col-sm-6">
                                <label class="control-label modal-label">Source of Funding:</label>
                            </div>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="sourceOfFunding">
                            </div>
                        </div>

                        <div class="row form-group mt-2">
                            <div class="col-sm-6">
                                <label class="control-label modal-label">Unit Cost:</label>
                            </div>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="unitCost" value="<?php echo $row['unitCost']; ?>" readonly>
                            </div>
                        </div>

                        <div class="row form-group mt-2">
                            <div class="col-sm-6">
                                <label class="control-label modal-label">Total Cost:</label>
                            </div>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="totalCost"  value="<?php echo $row['totalCost']; ?>" >
                            </div>
                        </div>

                        <div class="row form-group mt-2">
                            <div class="col-sm-6">
                                <label class="control-label modal-label">Date of Issue:</label>
                            </div>
                            <div class="col-sm-6">
                                <input type="date" class="form-control" name="dateOfIssue">
                            </div>
                        </div>
                        <div class="row form-group mt-2">
    <div class="col-sm-6">
        <label class="control-label modal-label">Remarks:</label>
    </div>
    <div class="col-sm-6">
        <select class="form-control" name="remarks">
            <option value="functional">Functional</option>
            <option value="non-functional">Non-Functional</option>
        </select>
    </div>
</div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-bs-dismiss="modal">
                                <span class="glyphicon glyphicon-remove"></span> Cancel
                            </button>
                            <button type="submit" name="moeeequipedit" class="btn btn-success">
                                Award
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
