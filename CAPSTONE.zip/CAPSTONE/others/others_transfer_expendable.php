<?php
include_once('../connection/connection.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve data from form
    $otherID =$_POST['otherID'];
    $teacherID = $_POST['teachersID']; // Correct name attribute
    $quantity = $_POST['quantity'];
    $unit = $_POST['unit'];
    $unitCost = $_POST['unitCost'];
    $category = $_POST['category'];
    $inventoryNo = $_POST['inventoryNo'];
    $sourceOfFunding = $_POST['sourceOfFunding'];
    $remarks = $_POST['remarks'];

    // Calculate total cost based on unit cost and quantity
    $totalCost = $unitCost * $quantity;

    // Insert data into teacheraccountability table using SQL JOIN
    $insert_query = "INSERT INTO teacheraccountability (teachersID, quantity, unitCost, totalCost, category, inventoryNo, sourceOfFunding, remarks) 
    SELECT '$teacherID', '$quantity', '$unitCost', '$totalCost', '$category', '$inventoryNo', '$sourceOfFunding', '$remarks'
    FROM teacher
    WHERE teachersID = '$teacherID'";

    if ($conn->query($insert_query) === TRUE) {
        // Update quantity in the original table (example assuming 'mooeinventory')
        $update_query = "UPDATE otherinventory 
        SET quantity = quantity - '$quantity', 
            totalCost = totalCost - ('$quantity' * unitCost)
        WHERE inventoryTypeID = 3
        AND inventorySubTypeID = 2 
        AND otherID = '$otherID'";

            if ($conn->query($update_query) === TRUE) {
            // Redirect after successful update
            header("Location: others_expendable_index.php");
            exit();
        } else { 
            echo "Error updating record: " . $conn->error;
        }
    } else {
        echo "Error inserting record: " . $conn->error;
    }

    // Close database connection
    $conn->close();
}
?>
