
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <title></title>
</head>
<style>
.rounded-full {
  border-radius: 100%;
}


#sidebar-wrapper {
  min-height: 100vh;
  margin-left: -15rem;
  -webkit-transition: margin 0.25s ease-out;
  -moz-transition: margin 0.25s ease-out;
  -o-transition: margin 0.25s ease-out;
  transition: margin 0.25s ease-out;
  
}

#sidebar-wrapper .sidebar-heading {
  padding: 0.875rem 1.25rem;
  font-size: 1.2rem;
}

#sidebar-wrapper .list-group {
  width: 15rem;
}

#page-content-wrapper {
  min-width: 100vw;
}

#wrapper.toggled #sidebar-wrapper {
  margin-left: 0;
}

#menu-toggle {
  cursor: pointer;
}

.list-group-item {
  border: none;
  padding: 20px 30px;
}

.list-group-item.active {
  background-color: transparent;
  color: var(--main-text-color);
  font-weight: bold;
  border: none;
}
#wrapper {
    display: flex;
}
nav {
    border-bottom: 1px solid #ddd; /* Idagdag ang horizontal line sa ilalim ng nav */
    margin-bottom: 20px; /* Magdagdag ng margin sa ibaba ng nav para magkaroon ng puwang */
}

#sidebar-wrapper {
    width: 250px; /* Ajustahin ang lapad ng sidebar base sa iyong design */
    height: 100vh; /* Itakda ang taas ng sidebar sa full height ng viewport */
    border-right: 1px solid #ddd; /* Idagdag ang vertical line */
}

@media (min-width: 768px) {
  #sidebar-wrapper {
    margin-left: 0;
  }

  #page-content-wrapper {
    min-width: 0;
    width: 100%;
  }

  #wrapper.toggled #sidebar-wrapper {
    margin-left: -15rem;
  }
}
</style>

<body>
<div class="d-flex" id="wrapper">
        <!-- Sidebar -->
        <div class="bg-white" id="sidebar-wrapper">
        <div class="sidebar-heading text-center primary-text fs-4 fw-bold text-uppercase border-bottom">
    <img src="../images/logo.png" alt="Logo" class="mb-3" style="width: 150px; height: auto; align-content:center;">
    <div style="font-family: sans-serif; color: #3f3a94; font-weight: bold; font-size: 2rem; text-align:center;">Inventory</div>
</div>
<div class="list-group list-group-flush my-3">
    <a href="../login/dashboard.php" class="list-group-item list-group-item-action bg-transparent second-text active">
        <i class="fas fa-chart-line me-2"></i>Dashboard
    </a>
    <div class="dropdown">
        <a class="list-group-item list-group-item-action bg-transparent second-text fw-bold dropdown-toggle" href="#" role="button" id="dropdownMOOE" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-money-bill-alt me-2"></i>MOOE
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownMOOE">
            <li><a class="dropdown-item" href="../mooe//mooe_supply_index.php"><i class="fas fa-shopping-cart me-2"></i>Supplies</a></li>
            <li><a class="dropdown-item" href="../mooe/mooe_expendable_index.php"><i class="fas fa-box-open me-2"></i>Semi-Expendable</a></li>
            <li><a class="dropdown-item" href="../mooe/mooe_equipment_index.php"><i class="fas fa-laptop me-2"></i>Property, Plant and Equipment</a></li>
        </ul>
    </div>
    <div class="dropdown">
        <a class="list-group-item list-group-item-action bg-transparent second-text fw-bold dropdown-toggle" href="#" role="button" id="dropdownDepEd" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-school me-2"></i>DepEd
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownDepEd">
            <li><a class="dropdown-item" href="#"><i class="fas fa-shopping-cart me-2"></i>Supplies</a></li>
            <li><a class="dropdown-item" href="../DepEd/deped_expendable_index.php"><i class="fas fa-box-open me-2"></i>Semi-Expendable</a></li>
            <li><a class="dropdown-item" href="../DepEd/deped_equipment_index.php"><i class="fas fa-laptop me-2"></i>Property, Plant and Equipment</a></li>
        </ul>
    </div>
    <div class="dropdown">
        <a class="list-group-item list-group-item-action bg-transparent second-text fw-bold dropdown-toggle" href="#" role="button" id="dropdownOthers" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-folder me-2"></i>Others
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownOthers">
            <li><a class="dropdown-item" href="#"><i class="fas fa-shopping-cart me-2"></i>Supplies</a></li>
            <li><a class="dropdown-item" href="others_expendable_index.php"><i class="fas fa-box-open me-2"></i>Semi-Expendable</a></li>
            <li><a class="dropdown-item" href="others_equipment_index.php"><i class="fas fa-laptop me-2"></i>Property, Plant and Equipment</a></li>
        </ul>
    </div>
    <a href="../teachers/teachers_index.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
        <i class="fas fa-chalkboard-teacher me-2"></i>Teachers
    </a>
    <a href="../teachers/accountability.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
    <i class="fas fa-users me-2"></i>Accountable List
</a>
    <a href="#" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
        <i class="fas fa-archive me-2"></i>Archived
    </a>
    <a href="../login/logout.php" class="list-group-item list-group-item-action bg-transparent text-danger fw-bold">
        <i class="fas fa-power-off me-2"></i>Logout
    </a>
</div>

</div>

        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <nav class="navbar navbar-expand-lg navbar-light bg-white py-4 px-4">
            <div class="d-flex align-items-center">
    <i class="fas fa-align-left primary-text fs-4 me-3" id="menu-toggle" style="z-index: 9999;"></i>
    <h2 class="fs-2 m-0"></h2>
</div>


            </nav>
     <div class="container-fluid mt-4">
        <div class="row mx-2">
            <div class="col-lg-12">
                <div class="row">
                    <?php
                        if(isset($_SESSION['error'])){
                            echo "
                            <div class='alert alert-danger text-center'>
                                <button class='close'>&times;</button>
                                ".$_SESSION['error']."
                            </div>";
                            unset($_SESSION['error']);
                        }
                        if(isset($_SESSION['success'])){
                            echo "
                            <div class='alert alert-success text-center'>
                                <button class='close'>&times;</button>
                                ".$_SESSION['success']."
                            </div>";
                            unset($_SESSION['success']);
                        }
                    ?>
                </div>
                <?php include('others_expendable_add_modal.php') ?>
                <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
    <b>Others: Semi-Expendable</b>
    <div>
        <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#othernewadd">
            <i class="fas fa-plus"></i> Add New
        </a>
        <button class="btn btn-secondary" onclick="printPage()">
            <i class="fas fa-print"></i> Print
        </button>
    </div>
</div>

                    <div class="card-body">
    <table id="myTable" class="table">
        <thead>
            <tr>
                <th>Quantity</th>
                <th>Unit</th>
                <th>Unit Cost</th>
                <th>Total Cost</th>
                <th>Description</th>
                <th>Inventory Item No.</th>
                <th>Estimated Useful Life</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php
            include_once('../connection/connection.php');
            $sql = "SELECT * FROM otherinventory where inventoryTypeID = 3 AND inventorySubTypeID = 2";
            $query = $conn->query($sql);
            while($row = $query->fetch_assoc()){
                echo "
                <tr>
                    <td>".$row['quantity']."</td>
                    <td>".$row['unit']."</td>
                    <td>".$row['unitCost']."</td>
                    <td>".$row['totalCost']."</td>
                    <td>".$row['category']."</td>
                    <td>".$row['inventoryNo']."</td>
                    <td>".$row['estimatedLife']."</td>
                    <td>
                    <a href='#otheredit".$row['otherID']."' class='btn btn-success btn-sm' data-bs-toggle='modal' data-bs-target='#otheredit".$row['otherID']."'><i class='fas fa-edit'></i></a>
                    <a href='#othertransfer2".$row['otherID']."' class='btn btn-primary btn-sm' data-bs-toggle='modal' data-bs-target='#othertransfer2".$row['otherID']."'><i class='fas fa-medal'></i></a>
                    </td>
                </tr>";
            }
        ?>
        </tbody>
    </table>
</div>

                </div>
            </div>
        </div>
    </div>
        </div>
</div>
    

    <!-- Edit Modals -->
    <?php
    $query = $conn->query($sql);
    while($row = $query->fetch_assoc()){
        include('others_expendable_edit_modal.php');
        include('others_award.php');
    }
    ?>

    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    
    <script>
        $(document).ready(function(){
            // Initialize DataTable
            $('#myTable').DataTable();

            // Hide alert
            $(document).on('click', '.close', function(){
                $('.alert').hide();
            });
        });
    </script>
    <script>
   $(document).ready(function(){
       $("#menu-toggle").click(function(e) {
           e.preventDefault();
           $("#wrapper").toggleClass("toggled");
       });
   });
</script>
<script>
    function printPage() {
        // Buksan ang print.php sa isang bagong window
        var printWindow = window.open('others_print_expendable.php', '_blank');

        // Focus sa bagong window at awtomatikong mag-print pagkatapos ng pag-load
        printWindow.onload = function() {
            printWindow.print();
        };
    }
</script>
</body>
</html>
